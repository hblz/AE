import utils from 'utils'
import REST from 'utils/restful'

export default class extends REST {
  constructor () {
    super()
    this.baseUri = [utils.TASK_API_ORIGIN, 'v0.1', 'admin/dict/{type}/query']
  }
}
