import utils from 'utils'
import eventable from 'decorators/eventable'
import URL from 'url-parse'
import urlParams from 'utils/urlParams'

/**
 * ELeaning 通信封装
 * @author 赵金添 <820514@nd>
 * @example
 * // 新建 ELeaning 实例
 * const eLeaning = new ELeaning()
 *
 * // 获取 e-learning URL 鉴权地址
 * eLeaning.getAuthURL()
 *
 * // 监听 loaded 事件
 * eLeaning.on('loaded', data => {
 *   console.log(data)
 * })
 *
 * // 通知 e-leaning，我需要初始化选中课程/培训
 * eLeaning.setItem({...})
 *
 * // 通知 e-leaning，我需要获取选中课程/培训
 * eLeaning.getItem()
 *
 * // 监听 set item 事件
 * eLeaning.on('set item', data => {
 *   console.log(data)
 * })
 */
@eventable
class ELeaning {

  constructor () {
    // 监听 message 事件
    // 对 e-leaning 发送过来的消息进行处理
    window.addEventListener('message', event => {
      const {event_type, data} = event.data

      switch (event_type) {
        // e-leaning 页面加载完成
        // 在这里对 e-leaning 初始化选中课程/培训，即：eLeaning.setItem({...})
        case 'loaded':
          this.emit('loaded', data)
          break

        // e-leaning 页面选完课程/培训
        case 'set_item':
          this.emit('set item', data)
          break

        default:
          break
      }
    })
  }

  /**
   * 向 e-leaning 发送消息
   * @param {string} event_type 消息类型
   * @param {object} data 消息数据
   * @private
   */
  _postMessage (event_type, data) {
    window.eLeaning.postMessage(JSON.stringify({event_type, data}), '*')
  }

  /**
   * URL 是否包含某个参数
   * @param {string} url URL
   * @param {string} param 参数
   * @return {boolean}
   * @private
   */
  _hasParam (url, param) {
    return url.indexOf(param) !== -1
  }

  /**
   * 通知 e-leaning，我需要初始化选中课程/培训
   * 在任务编辑时调用
   * @param {object} data 数据
   */
  setItem (data = {name: '', code: '', cmp_link: ''}) {
    this._postMessage('init_item', data)
  }

  /**
   * 通知 e-leaning，我需要获取选中课程/培训
   * 在点击确认时调用
   */
  getItem () {
    this._postMessage('get_item', null)
  }

  /**
   * 参数替换
   * @param {string} url URL 地址
   * @param {Object} options={} 路劲参数列表
   */
  _replace (url, options = {}) {
    let ret = url

    Object.keys(options).forEach(value => {
      ret = ret.replace(new RegExp(`{${value}}|:${value}`, 'img'), options[value])
    })

    return ret
  }

  /**
   * 获取 e-learning URL 鉴权地址
   * @param {object} url URL
   * @return {string}
   */
  getAuthURL (url) {
    const tent = urlParams.getParamObj()
    const orgType = utils.auth.isVorg() ? 1 : 0
    const orgId = utils.auth.getAuth('org_exinfo').org_id
    const vOrgId = utils.auth.getAuth('org_exinfo')['v_org_id'] || ''
    const vOrgName = utils.auth.isVorg() ? utils.auth.getVorgName() : ''

    // v_org_id 请放在 org_id 前面
    let replacedURL = this._replace(url, {
      v_org_id: vOrgId,
      org_id: vOrgId || orgId,
      org_type: orgType
    })

    if (!this._hasParam(replacedURL, 'vorg_id=') && vOrgId) {
      replacedURL += `&vorg_id=${vOrgId}`
    }

    if (!this._hasParam(replacedURL, 'vorg=') && vOrgName) {
      replacedURL += `&vorg=${vOrgName}`
    }

    if (!this._hasParam(replacedURL, 'sdp_app_id=') && tent['sdp-app-id']) {
      replacedURL += `&sdp_app_id=${tent['sdp-app-id']}`
    }

    const {pathname, query, host} = new URL(replacedURL)
    const path = pathname + query
    const mac = utils.auth.getSSOMac(path, host)

    return `${replacedURL}&__mac=${mac}`
  }
}

export default ELeaning
