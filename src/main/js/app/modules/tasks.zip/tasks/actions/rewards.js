import { createAction } from 'redux-actions'
import actionTypes from '../constants/index'
import RewardsModel from '../models/rewards'
import DictModel from '../models/dict'
import { inject } from 'store/middlewares/async'
import { promiseAll } from 'utils'

const _getRewardsList = (options) => {
  return new RewardsModel().GET(options)
}

const _queryDict = (options) => {
  let datas = options.data.items
  let set = new Set()
  let promiseArray = []
  if (datas.length !== 0) {
    for (let data of datas) {
      for (let item of data.reward_items) {
        set.add(item.item_code)
      }
    }
    promiseArray.push(new DictModel().POST({
      replacement: {
        type: 'rewards'
      },
      data: {
        item_codes: Array.from(set).join(',')
      }
    }))
  }
  return promiseAll(promiseArray)
}

export const getRewardsList = createAction(
  actionTypes.GET_REWARDS_LIST,
  options => ({
    _list: _getRewardsList(options),
    list: inject('_list').to(_queryDict)
  }),
  (options) => ({
    success: {
      // text: options.success.text,
      // handler: options.success.handler
    }
  })
)

export const delRewards = createAction(
  actionTypes.DEL_REWARDS,
  options => {
    return new RewardsModel().DELETE(options)
  },
  (options) => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    }
  })
)

export const addRewards = createAction(
  actionTypes.ADD_REWARDS,
  options => {
    return new RewardsModel().POST(options)
  },
  (options) => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    }
  })
)

export const putRewards = createAction(
  actionTypes.ADD_REWARDS,
  options => {
    return new RewardsModel().PUT(options)
  },
  (options) => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    }
  })
)

export const getRewardsById = createAction(
  actionTypes.GET_REWARDS_ID,
  options => {
    return _getRewardsList(options)
  },
  (options) => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    }
  })
)

