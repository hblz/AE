import { createAction } from 'redux-actions'
import actionTypes from '../constants/index'
import DictModel from '../models/dictAll'

const _getDictList = (options) => {
  return new DictModel().GET(options)
}

export const queryRewards = createAction(
  actionTypes.DICT_REWARDS,
  options => {
    return _getDictList(options)
  }
)

export const queryBonus = createAction(
  actionTypes.DICT_BONUS,
  options => {
    return _getDictList(options)
  }
)

export const queryCycle = createAction(
  actionTypes.DICT_CYCLE,
  options => {
    return _getDictList(options)
  }
)

