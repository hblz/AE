import * as tasksActions from './tasks'
import * as rewardsActions from './rewards'
import * as dictActions from './dict'
import * as activityActions from './activity'

export default {
  ...tasksActions,
  ...dictActions,
  ...rewardsActions,
  ...activityActions
}
