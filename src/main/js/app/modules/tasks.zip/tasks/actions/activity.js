import {createAction} from 'redux-actions'
import actionTypes from '../constants/index'
import ActivityModel from '../models/activity'
import UploadAuthModel from '../models/token'
import TokenUploadModel from 'components/upload/models/tokenUpload'
import {inject} from 'store/middlewares/async'
import moment from 'moment'
import utils from 'utils'
/**
 *  获取列表
 */
export function getActivityList (options) {
  const promise = new ActivityModel().GET(options)
  return {type: actionTypes.GET_ACTIVITYLIST, payload: promise}
}


/**
 * 新增/更新   用一个服务端去控制 [PUT] /v0.1/admin/activities 创建/更新活动信息
 */
export const putActivity = createAction(actionTypes.PUT_ACTIVITY, (options) => {
  return new ActivityModel().PUT(options)
}, options => ({
  success: {
    text: options.success.text,
    handler: options.success.handler
  },
  error: {
    text: null,
    handler: options.error.handler
  }
}))

/**
 *  /v0.1/admin/activities/actions/clone 租户活动克隆
 */
 export const cloneActivity = createAction(actionTypes.CLONE_ACTIVITY, (options) => {
   return new ActivityModel().onAny(function (opts) {
     opts.addPath = '/actions/clone'
   }).POST(options)
 }, options => ({
   success: {
     text: options.success.text,
     handler: options.success.handler
   },
   error: {
     text: null,
     handler: options.error.handler
   }
 }))


 /**
  *   /v0.1/admin/activities/actions/{type}/{activity_code} 活动启用/停用   type：动作类型 up/启用、down/停用
activity_code ：活动代码
  */
  export const updownActivity = createAction(actionTypes.UPDOWN_ACTIVITY, (options) => {
    return new ActivityModel().onAny(function (opts) {
      opts.addPath = '/actions/{type}/{activity_code}'
    }).PATCH(options)
  }, options => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    },
    error: {
      text: null,
      handler: options.error.handler
    }
  }))



  export const upload = createAction(actionTypes.UPLOAD,
    options => ({
      options: options,
      token: new UploadAuthModel().POST({
        data: {
          path: `/${utils.CS_SERVICE_TASKSYSTEM}/task_data/${moment().format('YYYYMMDD')}/${options.formData.icon}`
        }
      }),
      uploadRes: inject('token', 'options').to(_upload)
    }),
    options => ({
      showLoading: false,
      success: options.success,
      error: options.error
    })
  )


  function _upload(token, options) {
  let uploadArray = []

  let formData
  for (let data of options.formData) {
    formData = new FormData()
    formData = data
    formData.append('path', `/${utils.CS_SERVICE_TASKSYSTEM}/task_data/${moment().format('YYYYMMDD')}`)
    uploadArray.push(_uploadFileSession(token.data, formData))
  }
  return Promise.all(uploadArray).then(res => {
    return options.multiple ? res : res[0]
  })
}

function _uploadFileSession(tokenData, formData) {
  const {path,session} = tokenData
  return new TokenUploadModel({
    version: 'v0.1',
    api: `upload?session=${session}`
  }).POST({
    data: formData
  }).then(res => res.data)
}
