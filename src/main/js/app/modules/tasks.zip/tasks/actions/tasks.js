import { createAction } from 'redux-actions'
import actionTypes from '../constants/index'
import TasksModel from '../models/tasks'
import GlobalModel from '../models/global'
import CloneModel from '../models/clone'
import TasksCloneModel from '../models/tasksclone'
import SimpletaskModel from '../models/simpletask'
import TasklistsModel from '../models/tasklists'
import BusinessModel from '../models/business'
import StatusTypeModel from '../models/statusType'
import PresetTimeModel from '../models/presetTime'
import { inject } from 'store/middlewares/async'

const _getTaskList = (options) => {
  return new TasksModel().GET(options)
}

export const getTaskList = createAction(
  actionTypes.GET_TASKS_LIST,
  options => {
    return _getTaskList(options)
  }
)

export const getStatusType = createAction(
  actionTypes.GET_STATUSTYPE,
  options => {
    return new StatusTypeModel().GET()
  }
)

export const getTaskListCode = createAction(
  actionTypes.GET_TASKSLIST,
  options => {
    return new TasklistsModel().GET()
  }
)

export const getBusiness = createAction(
  actionTypes.GET_BUSINESS,
  options => {
    return new BusinessModel().GET(options)
  }
)

export const getPresetTimeTask = createAction(
  actionTypes.GET_PRESETTIME_TASK,
  options => {
    return new PresetTimeModel().GET(options)
  },
  options => ({
    error: {
      handler: options.success.handler
    }
  })
)

export const getTaskById = createAction(
  actionTypes.GET_TASKS_LIST,
  options => {
    return new TasksModel().GET(options)
  },
  (options) => ({
    success: {
      handler: options.success.handler
    }
  })
)

export const getGlobalTaskList = createAction(
  actionTypes.GET_TASKS_GLOBLE_LIST,
  options => {
    return new GlobalModel().GET(options)
  }
)

export const cloneGlobalTaskList = createAction(
  actionTypes.CLONE_GLOBAL_TASKS,
  options => {
    return new CloneModel().POST(options)
  },
  (options) => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    }
  })
)

export const cloneTask = createAction(
  actionTypes.UPDATE_TASKS,
  options => ({
    update: new TasksCloneModel().POST(options),
    info: options.list,
    list: inject('info').to(_getTaskList)
  }),
  (options) => ({
    success: {
      text: options.success && options.success.text,
      handler: options.success && options.success.handler
    }
  })
)

export const updateTask = createAction(
  actionTypes.UPDATE_TASKS,
  options => ({
    update: new TasksModel().PATCH(options),
    info: options.list,
    list: inject('info').to(_getTaskList)
  }),
  (options) => ({
    success: {
      text: options.success && options.success.text,
      handler: options.success && options.success.handler
    }
  })
)

export const postSimpletask = createAction(
  actionTypes.POST_SIMPLE_TASKS,
  options => {
    return new SimpletaskModel().POST(options)
  },
  (options) => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    }
  })
)

export const patchTask = createAction(
  actionTypes.POST_SIMPLE_TASKS,
  options => {
    return new TasksModel().PATCH(options)
  },
  (options) => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    }
  })
)

export const postTask = createAction(
  actionTypes.POST_TASKS,
  options => {
    return new TasksModel().POST(options)
  },
  (options) => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    }
  })
)

export const postGlobalTask = createAction(
  actionTypes.POST_GLOBAL_TASKS,
  options => {
    return new GlobalModel().POST(options)
  },
  (options) => ({
    success: {
      text: options.success.text,
      handler: options.success.handler
    }
  })
)
