import * as actionTypes from './action-types'
import i18n from 'i18n'
import '../i18n'
const t = i18n.getFixedT(null, 'tasks')

let TASK_STATUS,
  TASK_SHOW_PROGRESS,
  TASK_CYCLE,
  TASK_PRIORITY,
  TASK_AUTODELAY,
  TASK_JOIN_STATUS,
  REWARD_CYCLE,
  REWARD_AUTOGAIN,
  REWARD_FIXED,
  NULL_TIME,
  TASK_TYPE,
  TASK_PUSHIM,
  TASK_RESTART_INTERVAL,
  TASK_RESTART_TIMES,
  WEEK,
  ELEARNING_URL = 'elearning-task-gateway',
  RULE_WAY,
  ACTIVITY_STATUS,
  ACTIVITY_PUSH,
   ACTIVITY_PRIORITY,
      ACTIVITY_NEWBIE,
      ACTIVITY_FOREVER

i18n.on('added languageChanged', () => {
  NULL_TIME : '1970-01-01T00:00:00.000+0800'
    /**
   * @constant {boolean}  TASK_STATUS 任务状态类型 上下架
   */
  TASK_STATUS = {
    true: t('hasPush'),
    false: t('notPush')
  }

    /**
   * @constant {boolean}  TASK_SHOW_PROGRESS 是否显示任务进度
   */
  TASK_SHOW_PROGRESS = {
    true: t('hasShow'),
    false: t('notShow')
  }

    /**
   * @constant {boolean}  TASK_CYCLE 任务周期
   */
  TASK_CYCLE = {
    'DAY': t('cycleDay'),
    'WEEK': t('cycleWeek'),
    'MONTH': t('cycleMonth'),
    'YEAR': t('cycleYear'),
    'CUSTOM':t('cycleCustom'),
    'ONCE': t('cycleOnce')
  }

    /**
   * @constant {boolean}  TASK_PRIORITY 任务优先级
   */
  TASK_PRIORITY = {
    1: t('high'),
    2: t('medium'),
    3: t('low')
  }
    /**
   * @constant {boolean}  REWARD_CYCLE  发放周期
   */
  REWARD_CYCLE = {
    'DAY': t('cycleDay'),
    'WEEK': t('cycleWeek'),
    'MONTH': t('cycleMonth'),
    'YEAR': t('cycleYear'),
    'ONCE': t('cycleOnce')
  }

    /**
   * @constant {boolean}  REWARD_AUTOGAIN  发放方式
   */
  REWARD_AUTOGAIN = {
    true: t('autoGain'),
    false: t('handGain')
  }

      /**
     * @constant {boolean}  REWARD_FIXED  固定奖励
     */
  REWARD_FIXED = {
    true: t('autoGain'),
    false: t('handGain')
  }

    /**
   * @constant {boolean}  TASK_AUTODELAY 允许延期
   */
  TASK_AUTODELAY = {
    0: t('notDelay'),
    1: t('autoDelay')
  }
    /**
   * @constant {boolean}  TASK_JOIN_STATUS 任务接入状态
   */
  TASK_JOIN_STATUS = {
    true: t('joinOn'),
    false: t('joinOff')
  }

  /**
 * @constant {boolean}  TASK_TYPE 任务类型
 */
TASK_TYPE = {
  0: t('common'),
  1: t('random')
}

TASK_RESTART_TIMES = {
   '-1': t('noLimited'),
   0: t('noRestart')
  //  1: t('oneTimes'),
  //  2: t('twoTimes'),
  //  3: t('threeTimes')
}

TASK_RESTART_INTERVAL= {
   0: t('noRestartInterval')
  //  0.5: t('half'),
  //  1: t('1hour'),
  //  2: t('2hour'),
  //  24:t('1day')
}


WEEK = {
  1:"周一",
  2:"周二",
  3:"周三",
  4:"周四",
  5:"周五",
  6:"周六",
  7:"周日"
}
/**
* @constant {boolean}  TASK_PUSHIM 推送IM
*/
TASK_PUSHIM = {
  true: '是',
  false: '否'
}

/**
* @constant {boolean}  RULE_WAY  状态计算方式
*/
RULE_WAY = {
 0: '不调用',
 1: '同步调用',
 2: '异步调用'
}

/**
* @constant {boolean}  ACTIVITY_STATUS  "status":0 // 状态 0/上，1/上架
*/
ACTIVITY_STATUS = {
   0: '下架',
   1: '上架'
}

/**
* @constant {boolean}  ACTIVITY_PRIORITY  活动优先级 0/低，1/中，2/高
*/
ACTIVITY_PRIORITY = {
   0: '低',
   1: '中',
   2: '高'
}



/**
* @constant {boolean}  ACTIVITY_PUSH  0 不推送 1 弹窗推送
*/
ACTIVITY_PUSH = {
   0: '不推送',
   1: '弹窗推送'
}


/**
* @constant {boolean}  ACTIVITY_FOREVER  0 不推送 1 弹窗推送
*/
ACTIVITY_FOREVER = {
   true: '是',
   false: '否'
}



/**
* @constant {boolean}  ACTIVITY_NEWBIE  0 不推送 1 弹窗推送
*/
ACTIVITY_NEWBIE = {
   true: '是',
   false: '否'
}


})

i18n.emit('added')

export {
    TASK_STATUS,
    TASK_SHOW_PROGRESS,
    TASK_CYCLE,
    TASK_PRIORITY,
    TASK_AUTODELAY,
    TASK_JOIN_STATUS,
    REWARD_AUTOGAIN,
    REWARD_CYCLE,
    REWARD_FIXED,
    NULL_TIME,
    TASK_TYPE,
    TASK_PUSHIM,
    TASK_RESTART_INTERVAL,
    TASK_RESTART_TIMES,
    WEEK,
    ELEARNING_URL,
    RULE_WAY,
    ACTIVITY_STATUS,
    ACTIVITY_PUSH,
    ACTIVITY_PRIORITY,
    ACTIVITY_NEWBIE,
    ACTIVITY_FOREVER
  }
export default actionTypes
