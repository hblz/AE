import { keyMirror } from 'utils'

export default keyMirror({
  GET_TASKS_LIST: null,
  GET_TASKS_GLOBLE_LIST: null,
  GET_REWARDS_LIST: null,
  DEL_REWARDS: null,
  ADD_REWARDS: null,
  GET_REWARDS_ID: null,
  QUERY_DICT_LIST: null,
  CLONE_GLOBAL_TASKS: null,
  CLONE_TASKS: null,
  POST_SIMPLE_TASKS: null,
  POST_GLOBAL_TASKS: null,
  POST_TASKS: null,
  DICT_REWARDS: null,
  DICT_BONUS: null,
  DICT_CYCLE: null,
  UPDATE_TASKS: null,
  GET_BUSINESS: null,
  GET_TASKSLIST: null,
  GET_STATUSTYPE: null,
  UPLOAD: null,
  GET_ACTIVITYLIST: null,
  PUT_ACTIVITY: null,
  CLONE_ACTIVITY: null,
  GET_PRESETTIME_TASK: null,
  UPDOWN_ACTIVITY: null
})
