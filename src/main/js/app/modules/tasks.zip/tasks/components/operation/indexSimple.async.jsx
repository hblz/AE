import React, { PropTypes } from 'react'
import i18n from 'i18n'
import actionCreators from '../../actions'
import { message } from 'antd'
import { connect } from 'react-redux'
import { Breadcrumb } from 'antd'

import Operation from './operationSimple'
import utils from 'utils'

@connect(state => ({
  business: state.business,
  taskslist: state.taskslist,
  presetTimeTask: state.presetTimeTask,
  statusType: state.statusType
}), actionCreators)
export default class extends React.Component {
  static propTypes = {
    params: PropTypes.object.isRequired,
    getTaskById: PropTypes.func,
    getTaskListCode: PropTypes.func,
    getBusiness: PropTypes.func,
    getPresetTimeTask: PropTypes.func,
    queryCycle: PropTypes.func,
    getStatusType: PropTypes.func
  };

  constructor (props) {
    super()

    this.state = {}
    this.t = i18n.getFixedT(null, 'tasks')
    this.id = props.params.id
    this.clone = props.params.clone
  }

  componentDidMount () {
    if (this.id) {
      let options = {
        uri: this.id,
        success: {
          handler: this._callBack
        }
      }
      this.props.getTaskById(options)
      this.props.queryCycle('cycle')
    }
    this.props.getTaskListCode()
    this.props.getBusiness()
    this.props.getStatusType()
    this.props.getPresetTimeTask({
      params: {
        suid: utils.auth.getAuth().user_id
      },
      success: {
        handler: data => {
          if (data.code === 'DATE_CONFIG/APP_ROUTER_NOT_FOUND') {
            message.error('时间配置服务未开通，需要去门户上开通时间配置服务')
          } else {
            message.error(data.message)
          }
        }
      }
    })
  }

  _callBack = (data) => {
    this.refs.ops.setFormdatas(data)
  }

  render () {
    const { t } = this
    const opProps = {
      id: this.id,
      clone: this.clone
    }
    return <div>
        <Breadcrumb separator='>'>
          <Breadcrumb.Item href='#/'>{t('home')}</Breadcrumb.Item>
          <Breadcrumb.Item>{'任务配置'}</Breadcrumb.Item>
          <Breadcrumb.Item href={'#/tasks/list'}>{'任务管理'}</Breadcrumb.Item>
          <Breadcrumb.Item>{this.clone ? '克隆' : this.id ? t('edit') : t('add')}{'简单任务'}</Breadcrumb.Item>
        </Breadcrumb>
        <Operation ref='ops'
                   {...opProps}
                   {...this.props}/>
    </div>
  }
}
