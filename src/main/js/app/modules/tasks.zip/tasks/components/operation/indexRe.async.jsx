import React, { PropTypes } from 'react'
import i18n from 'i18n'
import actionCreators from '../../actions'

import { connect } from 'react-redux'
import { Breadcrumb } from 'antd'

import Operation from './operationRe'

@connect(state => ({
  dicts: state.dicts
}), actionCreators)
export default class extends React.Component {
  static propTypes = {
    params: PropTypes.object.isRequired,
    getRewardsById: PropTypes.func,
    dicts: PropTypes.object,
    queryRewards: PropTypes.func,
    queryBonus: PropTypes.func
  };

  constructor (props) {
    super()

    this.state = {}
    this.t = i18n.getFixedT(null, 'tasks')
    this.id = props.params.id
    this.reId = props.params.reId
  }

  componentDidMount () {
    if (this.reId) {
      let options = {
        uri: this.reId,
        success: {
          handler: this._callBack
        }
      }
      this.props.getRewardsById(options)
    } else {
      this._queryDict()
    }
  }

  _queryDict = () => {
    let op = {
      uri: 'bonus',
      params: {
        $count: true,
        $limit: 1000
      }
    }
    this.props.queryBonus(op)
    let op1 = {
      uri: 'rewards',
      params: {
        $count: true,
        $limit: 1000
      }
    }
    this.props.queryRewards(op1)
  }

  _callBack = (data) => {
    this.refs.ops.setFormdatas(data)
    this._queryDict()
  }

  render () {
    const { t } = this
    const opProps = {
      id: this.reId,
      taskId: this.id,
      datas: this.props.dicts
    }
    return <div>
        <Breadcrumb separator='>'>
          <Breadcrumb.Item href='#/'>{t('home')}</Breadcrumb.Item>
          <Breadcrumb.Item>{'任务配置'}</Breadcrumb.Item>
          <Breadcrumb.Item href={'#/tasks/list'}>{'任务管理'}</Breadcrumb.Item>
          <Breadcrumb.Item href={`#/tasks/rewards/${this.id}`}>{`奖励列表(任务代码：${this.id})`}</Breadcrumb.Item>
          <Breadcrumb.Item>{this.reId ? t('edit') : t('add')}{'奖励'}</Breadcrumb.Item>
        </Breadcrumb>
        <Operation ref='ops'
                   {...opProps}
                   {...this.props}/>
    </div>
  }
}
