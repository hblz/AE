import React, { PropTypes } from 'react'
import i18n from 'i18n'

import { Input, Checkbox } from 'antd'
export default class extends React.Component {
  static propTypes = {
    bonus: PropTypes.array,
    rewark: PropTypes.object,
    bonus_items: PropTypes.array,
    reward_items: PropTypes.array
  }

  static defaultProps = {
  }

  state = {
    status: {
    },
    formData: {
    },
    name: undefined,
    isCheck: false
  }

  t = i18n.getFixedT(null, 'tasks')

  componentDidMount () {
    let items = []
    if (this.props.bonus && this.props.bonus.length > 0) {
      items = this.props.bonus
      this.state.name = this.props.rewark.default_val ? this.props.rewark.default_val + '' : ''
      for (let i = 0; i < items.length; i++) {
        this.setState({
          [`name${i}`]: items[i].default_val ? items[i].default_val + '' : ''
        })
      }
    }

    items = this.props.reward_items || []
    for (let i = 0; i < items.length; i++) {
      if (items[i].item_code === this.props.rewark.item_code) {
        this.setState({
          isCheck: true,
          name: items[i].num ? items[i].num + '' : ''
        })
      }
    }

    items = this.props.bonus_items || []
    for (let i = 0; i < items.length; i++) {
      let reward_items = items[i].reward_items
      for (let j = 0; j < reward_items.length; j++) {
        if (reward_items[j].item_code === this.props.rewark.item_code) {
          this.setState({
            [`name${i}`]: reward_items[j].num ? reward_items[j].num + '' : ''
          })
        }
      }
    }
  }

  _onChange = (e) => {
    this.setState({
      isCheck: e.target.checked
    })
  }

  _handleItem = (key, e) => {
    this.setState({
      [key]: e.target.value
    })
  }

  getStatus = () => {
    return this.state
  }

  render () {
    const { t } = this
    const that = this
    let items = []
    if (this.props.bonus && this.props.bonus.length > 0) {
      items = this.props.bonus
    }
    return <div>
        <ul className='content-ul'>
          <li>
            <label><Checkbox
              checked={this.state.isCheck}
              onChange={this._onChange}/>
              {this.props.rewark.name}
            </label>
          </li>
          <li>
            <Input disabled={!this.state.isCheck}
              defaultValue={this.props.rewark.default_val}
              value ={that.state.name}
              onChange={this._handleItem.bind(this, 'name')}/>
          </li>
          {
            items.map((item, key) => {
              return <li key = {key}>
                      <Input defaultValue={item.default_val} disabled={!this.state.isCheck} value ={that.state[`name${key}`]} onChange={this._handleItem.bind(this, `name${key}`)}/>
                    </li>
            })
          }
        </ul>
    </div>
  }
}
