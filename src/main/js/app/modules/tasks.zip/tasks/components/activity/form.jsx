import React, {PropTypes} from 'react'
import {
  Modal,
  Button,
  Validation,
  Form,
  Input,
  InputNumber,
  Radio,
  DatePicker,
  Select,
  message,
  Row,
  Col
} from 'antd'
import i18n from 'i18n'
import utils from 'utils'
import time from 'utils/time'
import moment from 'moment'
import classNames from 'classnames'
import {connect} from 'react-redux'
import actionCreators from 'modules/tasks/actions'
import {  ACTIVITY_STATUS,
  ACTIVITY_PUSH,
   ACTIVITY_PRIORITY,
      ACTIVITY_NEWBIE,
      ACTIVITY_FOREVER} from '../../constants'
import Uploader from './upload'
import { objectIsEqual } from '../utils/util'
import { cloneDeep } from 'lodash'
import './static/style.scss'
const Validator = Validation.Validator
const FormItem = Form.Item
const RadioGroup = Radio.Group
const Option = Select.Option
const t = i18n.getFixedT(null, 'tasks')

const AddForm = React.createClass({
  mixins: [Validation.FieldMixin],
  getInitialState () {
    this.t = i18n.getFixedT(null, 'tasks')
    return {
      visible: false,
      status: {
        activity_code : {},
        name : {},
        logo:{},
        // start_time : {},
        // end_time : {},
        desc : {},
        link: {},
        priority : {},
        push_way : {},
        forever: {},
        newbie: {},
        week: {},
        propaganda : {}
      },
      id: '',
      formData: {
        activity_code : undefined,
        name : undefined,
        logo: undefined,
        link: undefined,
        forever: true,
        newbie: true,
        week: 1,
        start_time : new Date(),
        end_time : new Date(new Date() * 1 + 1000 * 60 * 60 * 24 ),  // 推迟一天
        desc : undefined,
        priority : '1',
        push_way : '0',
        propaganda : undefined
      },
      formDataCopy: {},
      timePickerStatus: { newbie: true, forever: true, range: true, week: false }
    }
  },

  componentDidMount () {
    // let options = {}
    // options.params = {}
    // options.params.$count = true
    // options.params.$limit = 1000
    //
    // this.props.getTemplate({
    //   ...options
    // })
  },

  // shouldComponentUpdate (nextProps, nextState) {
  //   const state = !objectIsEqual(this.state, nextState)
  //   const prop = !objectIsEqual(this.props, nextProps)
  //   return state || prop
  // },

  componentWillReceiveProps (nextProps) {
    if (nextProps.type === 'edit' && nextProps.record !== null) {
      this.setState({
        id: nextProps.record.id,
        formData: {
            ...nextProps.record
        }
      },()=>{
          ['logo','propaganda'].map(
            (item)=>{
              let filesPres = []
              let files = {
                uid: nextProps.record[item],
                name: '',
                status: 'done',
                url: `${nextProps.record[item]}`,
                thumbUrl: `${nextProps.record[item]}?size=120`
              }
              if(files.uid){
                    filesPres.push(files)
              }
              this.refs[item].getWrappedInstance().setOldFile(filesPres)
            }
          )
      })
    } else {
      this.setState(this.getInitialState(),()=>{
        ['logo','propaganda'].map(
          (item)=>{
            if(  this.refs[item]) {
              this.refs[item].getWrappedInstance().setOldFile([])
            }
          }
        )
      })
    }
  },

  showModal () {
    this.setState({visible: true})
  },


   handleOk (e) {
    e.preventDefault()
    const validation = this.refs.validation
    validation.validate((valid) => {
      if (!valid) {
        return
      } else {
        let formData = this.state.formData
        const proUpload = ['logo','propaganda'].map(
          (item ,index)=>{
                  let iconObj = this.refs[item].getWrappedInstance().getFile()
                  if (iconObj.length > 0 ) {
                    let uploadArray = []
                    let uploaders = {
                       [item]: this.refs[item].getWrappedInstance()
                     }
                     if (this.props.type !== 'add') {
                      // 图片重新选择后，需重新长传
                      Object.keys(uploaders).forEach(key => {
                        let files = uploaders[key].getFile() || []
                        if (files.every(file => file.dentryId !== undefined)) { // not change
                          uploadArray.push(Promise.resolve({
                            dentry_id: formData[key]
                          }))
                        } else {
                          uploadArray.push(uploaders[key].upload())
                        }
                      })
                    } else {
                      uploadArray = Object.keys(uploaders).map(key => {
                        return uploaders[key].upload()
                      })
                    }
                    return Promise.all(uploadArray).then(res => {
                      if(res.length > 0){
                        if(res[0].path){
                          formData[item] = `${utils.CS_API_ORIGIN}/v0.1/download/actions/direct?dentryId=${res[0].dentry_id}&attachment=true` // dentry_id形式
                          // formData[item] = `${utils.CS_API_ORIGIN}/v0.1/static${res[0].path}`
                        }
                      }
                     }).catch(err => {
                       message.error('上传图标失败' + err.message)
                       console.log(111, `upload ${item} failed`, err)
                     })

                  } else {
                      formData[item] = ''
                  }
                }
              )


                Promise.all(proUpload).then(res => {
                  // 这里做 图标 必填的分发校验   宣传图不校验
                  let correct = true;
                  const chackList = Boolean(parseInt(formData.push_way, 10)) ? ['logo', 'propaganda'] : ['logo']
                  chackList.map(
                     (field)=>{
                      if( !formData[field] ){
                        correct = false
                      }
                     }
                   )
                   if(correct){
                     if( formData.start_time  && formData.end_time && moment(formData.start_time) >= moment(formData.end_time)  ){
                        message.warn('请确保时间选择正确！')
                     }else{
                       this.props.submit(this.props.type, formData, this.state.id)
                       this.handleReset(e)
                     }
                   }else{
                     message.warn('请确保必填图标都已选择！')
                   }

                })
      }
    })
  },
  handleCancel (e) {
    this.handleReset(e)
    this.props.hide()
  },
  handleReset (e) {
    this.refs.validation.reset()
    const {type} = this.props
    if(type === 'add'){
      ['logo','propaganda'].map(
        (item)=>{
          if(  this.refs[item] ) {
            this.refs[item].getWrappedInstance().setFile(null)
          }
        }
      )
    }
    this.setState(this.getInitialState())
  },
  handleKeyDown (e) {
    if (e.keyCode === 13) {
      this.handleOk(e)
    }
  },
  renderValidateStyle (item) {
    const formData = this.state.formData
    const status = this.state.status

    const classes = classNames({
      'error': status[item].errors,
      'validating': status[item].isValidating,
      'success': formData[item] && !status[item].errors && !status[item].isValidating
    })

    return classes
  },

  isNumber (value) {
    return /^-{0,1}\d*\.{0,1}\d+$/.test(value)
  },
  _checkCode (rule, value, callback) {
    if (value && /^[a-zA-Z_0-9]{3,100}$/.test(value)) {
      callback()
    } else {
      callback('3-100位英文数字组合')
    }
  },

  _checkURL (rule, value, callback) {
    if (typeof value === 'undefined' || typeof  value === 'object') {
      callback()
    }
    if (typeof value === 'string' && value.length === 0){
      callback()
    }
    if (value && /^(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?$/.test(value)) {
      callback()
    } else {
      callback(this.t('tips.url_check'))
    }
  },

  _checkDefaultVal (rule, value, callback) {
    if (typeof value === 'undefined' || typeof  value === 'object') {
      callback()
    }
    if (typeof value === 'string' && value.length === 0){
      callback()
    }
    if ( value && /^\d+$/.test(value) && parseInt(value + ''.trim(), 10) >= 0 && parseInt(value + ''.trim(), 10) <= 99999 ) {
      callback()
    } else {
      callback(this.t('tips.default_val'))
    }
  },
  checkStr (rule, value, callback) {
    const msg = t('inputStr')
    if (Boolean(value)) {
      value = value.replace(/\s/g, '')
      if (value.trim().length <= 0 || value.trim().length > 20) {
        callback(msg)
      }
    }
    callback()
  },

  _checkType (rule, value, callback) {
    if (+value > 100 || +value < 0) {
       callback(new Error('0-100!'));
     } else {
       callback();
     }
  },

  checkBoolean (item) {
    return item && (item.constructor === String ? item === 'true' : item)
  },

  checkStatue (formData) {
    const {formDataCopy} = this.state
    if (!objectIsEqual(formData, formDataCopy)) {
      const timePicker = {
        newbie: { newbie: true, forever: false, range: false, week: true },
        forever: { newbie: false, forever: true, range: false, week: false },
        range: { newbie: false, forever: false, range: true, week: false },
        all: { newbie: true, forever: true, range: true, week: false }
      }
      const isRange = (formData.start_time || formData.end_time)
      const timePickerStatus = this.checkBoolean(formData.newbie) ? timePicker.newbie : (this.checkBoolean(formData.forever) ? timePicker.forever : (isRange ? timePicker.range : timePicker.all))
      const formDataInit = {
        ...formData,
        newbie: timePickerStatus.newbie ? formData.newbie : 'false',
        forever: timePickerStatus.forever ? formData.forever : 'false',
        start_time: timePickerStatus.range ? formData.start_time : undefined,
        end_time: timePickerStatus.range ? formData.end_time : undefined,
        week: timePickerStatus.newbie ? formData.week : undefined
      }
      this.state.timePickerStatus = timePickerStatus
      this.state.formData = formDataInit
      this.state.formDataCopy = formDataInit
    }
    return
  },

  reset () {
    // 这里不知道为什么 上一个人把 status里面的start_time， end_time 注释了，不敢乱改 就直接这样搞了
    const stateNew = {
      ...this.state.formData,
      start_time: undefined,
      end_time: undefined
    }
    this.setState({formData: stateNew})
  },

  /**
   * 禁用开始时间
   */
  _disabledStartDate (current)  {
     return current && current.getTime() < Date.now() - 1000 * 60 * 60 * 24
  },

  /**
   * 禁用结束时间
   */
  _disabledEndDate (current) {
     return current && current.getTime() < moment(this.state.formData.start_time);
  },

  render () {
    this.checkStatue(cloneDeep(this.state.formData))
    const { formData, timePickerStatus, status } = this.state
    const { type } = this.props

    let priorityOptions = []
    for (let index in ACTIVITY_PRIORITY) {
      priorityOptions.push(
        <Radio key={index + 'priority'} value={`${index}`}>
          {ACTIVITY_PRIORITY[index]}</Radio>
      )
    }

    let pushOptions = []
    for (let index in ACTIVITY_PUSH) {
      pushOptions.push(
        <Radio key={index + 'push'} value={`${index}`}>
          {ACTIVITY_PUSH[index]}</Radio>
      )
    }

    let foreverOptions = []
    for (let index in ACTIVITY_FOREVER) {
      foreverOptions.push(
        <Radio key={index + 'forever'} value={`${index}`}>
          {ACTIVITY_FOREVER[index]}</Radio>
      )
    }

    let newbieOptions = []
    for (let index in ACTIVITY_FOREVER) {
      newbieOptions.push(
        <Radio key={index + 'newbie'} value={`${index}`}>
          {ACTIVITY_FOREVER[index]}</Radio>
      )
    }

    let title = type === 'edit' ? '编辑' : '新增'
    const propagandaRequire = Boolean(parseInt(formData.push_way, 10)) ? {required: true, className: 'propagandaRequire'} : {required: false, className: 'propagandaRequireDis'}
    return <div>
      <Modal title={title} width={750} className='activityModal'   visible={this.props.visible} footer={[< Button type = 'ghost' size = 'large' key = {1}
        className = 'margin-right1' onClick = {this.handleCancel}> { t('cancel') } </Button>,
         <Button type='primary' size='large' key={2} onClick={this.handleOk}>{t('confirm')}</Button >,
         <Button size='large' key={2} onClick={this.reset}>{t('reset')}</Button >,
         <Button type='ghost' size='large' key={2} onClick={this.reset}>{t('reset')}</Button >]} onCancel={this.handleCancel}>
        <Form horizontal>
          <Validation ref='validation' onValidate={this.handleValidate}>

          <FormItem
              label={`活动Logo：` }
              required
              labelCol={{
                span: 7
              }} wrapperCol={{
                span: 16
              }} >
              <div>
                <Uploader
                  ref="logo"
                  multiple={false}
                  dentryIds={formData.logo ? [formData.logo] : undefined} />
                {/* <div>{t('activityIcon') }</div> */}
              </div>
            </FormItem>

      {
        type === 'add' ?  <FormItem label={'活动代码' + '：'} labelCol={{
            span: 7
          }} wrapperCol={{
            span: 16
          }} validateStatus={this.renderValidateStyle('activity_code')} hasFeedback help={status.activity_code.isValidating
            ? '填写' + '活动代码'
            : status.activity_code.errors
              ? status.activity_code.errors.join(',')
              : null} required>
            <Validator rules={[
              {
                required: true,
                message: t('tips.requireTips')
              }, {
                validator: this._checkCode
              }
            ]}>
              <Input name='activity_code' value={formData.activity_code}  placeholder={'填写' + '活动代码'} onKeyDown={this.handleKeyDown} />
            </Validator>
          </FormItem> : null
      }

          <FormItem label={'活动名称' + '：'} labelCol={{
            span: 7
          }} wrapperCol={{
            span: 16
          }} validateStatus={this.renderValidateStyle('name')} hasFeedback help={status.name.isValidating
            ? '填写' + '活动名称'
            : status.name.errors
              ? status.name.errors.join(',')
              : null} required>
            <Validator rules={[
              {
                required: true,
                message: t('tips.requireTips')
              }, {
                max: 30,
                message: t('tips.maxTips', {n: 30})
              }
            ]}>
              <Input name='name' value={formData.name}  placeholder={'填写' + '活动名称'} onKeyDown={this.handleKeyDown} />
            </Validator>
          </FormItem>

          <Row>
            <Col style={{height: '1px', width: '6.2%'}} span='1' />
            <Col span='19'>
              <FormItem  label={'时间' + '：'} labelCol={{
                span: 7
              }} wrapperCol={{
                span: 16
              }} required>
                <div style={{ display: "flex"}}>
                  <DatePicker showTime   name='start_time'  format={'yyyy-MM-dd HH:mm'} disabled={!(timePickerStatus && timePickerStatus.range)}
                        disabledDate={this._disabledStartDate} onChange={
                          (value)=>{
                            this.setState({
                              formData: {
                                ...formData,
                                start_time: value === null ? moment().format() : moment(value).format()
                              }
                            })
                          }
                        } value={moment(formData.start_time).format('YYYY-MM-DD HH:mm')}/>
                  <span style={{ margin: '0 5px',lineHeight:'32px'}}> 至 </span>
                  <DatePicker  showTime  name='end_time'  format={'yyyy-MM-dd HH:mm'} disabled={!(timePickerStatus && timePickerStatus.range)}
                        disabledDate={this._disabledEndDate} onChange={
                          (value)=>{
                            this.setState({
                              formData: {
                                ...formData,
                                end_time: value === null ? moment().format() : moment(value).format()
                              }
                            })
                          }
                        } value={moment(formData.end_time).format('YYYY-MM-DD HH:mm')}/>
                </div>
              </FormItem>
            </Col>
            <Col span='3'>
              <Button disabled={!(timePickerStatus && timePickerStatus.range)} key={2} onClick={this.reset}>{t('reset')}</Button >
            </Col>
          </Row>

          <FormItem label={'活动介绍' + '：'} labelCol={{
            span: 7
          }} wrapperCol={{
            span: 16
          }} validateStatus={this.renderValidateStyle('desc')} hasFeedback={false} help={status.desc.isValidating
            ? '填写' + '活动介绍'
            : status.desc.errors
              ? status.desc.errors.join(',')
              : null} required>
            <Validator rules={[
              {
                required: true,
                message: t('tips.requireTips')
              }, {
                max: 330,
                message: t('tips.maxTips', {n: 330})
              }
            ]}>
              <Input name='desc'  style={{ height: 60 }}  value={formData.desc}  type='textarea' placeholder={'填写' + '活动介绍'} onKeyDown={this.handleKeyDown} />
            </Validator>
          </FormItem>

            <FormItem label={'优先级' + '：'} labelCol={{
              span: 7
            }} wrapperCol={{
              span: 16
            }} validateStatus={this.renderValidateStyle('priority')} hasFeedback={false} help={status.priority.isValidating
              ? t('templatePlaceholder')
              : status.priority.errors
                ? status.priority.errors.join(',')
                : null} required>
                <Validator rules={[{
                  required: true,
                  message: '必选'
                }
                ]}>
                  <RadioGroup value={formData.priority + ''}  name='priority' >
                    {priorityOptions}
                  </RadioGroup>
                </Validator>
            </FormItem>

            <FormItem label={'推送类型' + '：'} labelCol={{
              span: 7
            }} wrapperCol={{
              span: 16
            }} validateStatus={this.renderValidateStyle('push_way')} hasFeedback={false} help={status.push_way.isValidating
              ? t('templatePlaceholder')
              : status.push_way.errors
                ? status.push_way.errors.join(',')
                : null} required>
                <Validator rules={[{
                  required: true,
                  message: '必选'
                }
                ]}>
                  <RadioGroup value={formData.push_way + ''}  name='push_way' >
                    {pushOptions}
                  </RadioGroup>
                </Validator>
            </FormItem>
            <FormItem label={'活动时间是否永久' + '：'} labelCol={{
              span: 7
            }} wrapperCol={{
              span: 16
            }} validateStatus={this.renderValidateStyle('forever')} hasFeedback={false} help={status.forever.isValidating
              ? t('templatePlaceholder')
              : status.forever.errors
                ? status.forever.errors.join(',')
                : null} required>
                <Validator rules={[{
                  required: true,
                  message: '必选'
                }
                ]}>
                  <RadioGroup value={formData.forever + ''}  name='forever'disabled={!(timePickerStatus && timePickerStatus.forever)} >
                    {foreverOptions}
                  </RadioGroup>
                </Validator>
            </FormItem>

            <FormItem label={'是否新手任务' + '：'} labelCol={{
              span: 7
            }} wrapperCol={{
              span: 16
            }} validateStatus={this.renderValidateStyle('newbie')} hasFeedback={false} help={status.newbie.isValidating
              ? t('templatePlaceholder')
              : status.newbie.errors
                ? status.newbie.errors.join(',')
                : null} required>
                <Validator rules={[{
                  required: true,
                  message: '必选'
                }
                ]}>
                  <RadioGroup value={formData.newbie + ''}  name='newbie' disabled={!(timePickerStatus && timePickerStatus.newbie)} >
                    {newbieOptions}
                  </RadioGroup>
                </Validator>
            </FormItem>

            <FormItem label={'N周后失效时间' + '：'} labelCol={{
              span: 7
            }} wrapperCol={{
              span: 16
            }} validateStatus={this.renderValidateStyle('week')} hasFeedback={false} help={status.week.isValidating
              ? t('templatePlaceholder')
              : status.week.errors
                ? status.week.errors.join(',')
                : null} required>
                <Validator rules={[{
                  validator: this._checkType
                }
                ]}>
                <InputNumber min={0} max={100} name='week' style={{ width: 100 }} value={formData.week } disabled={!(timePickerStatus && timePickerStatus.week)} />
                </Validator>
            </FormItem>

            <Row className={`ant-form-item ${propagandaRequire.className}`}>
              <FormItem
                  label={`弹窗宣传图：` }
                  required={Boolean(parseInt(formData.push_way, 10))}
                  labelCol={{
                    span: 7
                  }} wrapperCol={{
                    span: 16
                  }} >
                  <div>
                    <Uploader
                      ref="propaganda"
                      multiple={false}
                      dentryIds={formData.propaganda ? [formData.propaganda] : undefined} />
                    {/* <div>{t('activityIcon') }</div> */}
                  </div>
                </FormItem>
            </Row>

              <FormItem label={'跳转链接' + '：'} labelCol={{
                span: 7
              }} wrapperCol={{
                span: 16
              }} validateStatus={this.renderValidateStyle('link')} hasFeedback help={status.link.isValidating
                ? '填写' + '跳转链接'
                : status.link.errors
                  ? status.link.errors.join(',')
                  : null} required={false}>
                <Validator rules={[
                  {
                    required: false,
                    message: t('tips.requireTips')
                  }
                ]}>
                  <Input name='link' value={formData.link}  placeholder={'填写' + '跳转链接'} onKeyDown={this.handleKeyDown} />
                </Validator>
              </FormItem>


          </Validation>
        </Form>
      </Modal>
    </div>
  }
})

export default connect(state => {
  return {
    activitylist: state.activitylist,
    rewards: state.rewards
  }
}, actionCreators)(AddForm)
