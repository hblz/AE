import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import utils from 'utils'
import { Button, Input, Form, Breadcrumb } from 'antd'
import actionCreators from '../../actions'
import i18n from 'i18n'
import List from 'components/list/index'
import { Confirm } from 'components/dialog/index'

const t = i18n.getFixedT(null, 'log')
const FormItem = Form.Item

@connect(state => ({
  rewards: state.rewards
}), actionCreators)
export default class extends React.Component {
  static propTypes = {
    getRewardsList: PropTypes.func,
    delRewards: PropTypes.func,
    history: PropTypes.object,
    rewards: PropTypes.object,
    params: PropTypes.object
  }
  constructor (props) {
    super(props)
    this.state = {
      reId: undefined,
      visible: false,
      pageSize: utils.PAGE_SIZE,
      currentPage: 1,
      reward_name: undefined,
      id: props.params.id
    }
  }

  componentDidMount () {

  }

  _getList = (options, page) => {
    this.state.currentPage = page
    let params = {
      ...options.params,
      taskCode: this.state.id
    }
    if (this.state.reward_name) {
      params.$filter = `rewardName like ${this.state.reward_name}`
    }
    delete params.$orderby
    this.props.getRewardsList({
      params: params
    })
  }

  _onChange = (field, e) => {
    this.setState({
      [field]: e.target.value.trim()
    })
  }

  _submit = () => {
    let options = {}
    options.params = {
      $limit: this.state.pageSize,
      $count: true,
      $offset: 0
    }
    this._getList(options, 1)
  }

  _handleDel = (id) => {
    this.setState({
      reId: id,
      visible: true
    })
  }

  _handleAdd = (id) => {
    this.props.history.pushState(null, `tasks/operationRe/${this.state.id}/` + id)
  }

  _handleKeyDown = (e) => {
    if (e.keyCode === 13) {
      this._submit()
    }
  }

  render () {
    const _self = this
    let listProps = {
      // 数据
      data: this.props.rewards,
      currentPage: this.state.currentPage,
      // 参数
      restParams: {
        params: {
          $limit: this.state.pageSize,
          $count: true
        }
      },
      operation: {
        title: t('operation'),
        dataIndex: '',
        render: function (text, record) {
          return <span className='operate-group'>
            <span className='operate-item' onClick={_self._handleAdd.bind(this, record.reward_code)}>
              {'编辑'}
            </span>
            <span className='operate-item' onClick={_self._handleDel.bind(this, record.reward_code)}>
              {'删除'}
            </span>
          </span>
        }
      },
      columnsData: [
        {
          title: '奖励名称',
          width: '30em',
          dataIndex: 'reward_name',
          render: function (text, record) {
            return <span className='ellipsis max-width-30' title={`${text}(${record.reward_code})`}>{`${text}(${record.reward_code})`}</span>
          }
        }, {
          title: '发放周期',
          dataIndex: 'cycle',
          render: function (text, record) {
            let msg = '无'
            switch (text) {
              case 'DAY':
                msg = '每日'
                break
              case 'week':
                msg = '每周'
                break
              case 'MONTH':
                msg = '每月'
                break
              case 'YEAR':
                msg = '每年'
                break
              case 'ONCE':
                msg = '一次性'
                break
            }
            return (
                    <span className='ellipsis max-width-5' title={text}>{msg}</span>
                   )
          }
        }, {
          title: '发放次数',
          dataIndex: 'limit',
          render: function (text, record) {
            return (
                    <span className='ellipsis max-width-5' title={text}>{text}</span>
                   )
          }
        }, {
          title: '发放方式',
          dataIndex: 'auto_gained',
          render: function (text, record) {
            let msg = text ? '自动发放' : '手动领取'
            return (
                    <span className='ellipsis max-width-5'>{msg}</span>
                   )
          }
        }, {
          title: '固定奖励',
          dataIndex: 'fixed',
          render: function (text, record) {
            let msg = text ? '是' : '否'
            return (
                    <span className='ellipsis max-width-5'>{msg}</span>
                   )
          }
        }, {
          title: '奖励有效期',
          dataIndex: 'validate_days',
          render: function (text, record) {
            return (
                    <span className='ellipsis max-width-5' title={text}>{`${text}天`}</span>
                   )
          }
        }, {
          title: '奖励明细（普通用户奖励）',
          dataIndex: 'reward_items',
          render: function (text, record) {
            return (
                    <span className='ellipsis max-width-10 overflow-s'>
                      {
                        text.map((item, key) => {
                          return <div key={key}>
                              {`${item.name || item.item_code}: ${item.num || ''}`}
                            </div>
                        })
                      }
                    </span>
                   )
          }
        }
      ],
      labelMap: {
        reward_name: '奖励名称',
        cycle: '发放周期',
        limit: '发放次数',
        auto_gained: '发放方式',
        fixed: '固定奖励',
        validate_days: '奖励有效期',
        reward_items: '奖励明细（普通用户奖励）'
      },
      inFilter: function (data) {
        data['key'] = data['reward_code']
        return data
      },
      fetch: _self._getList
    }
    return (
      <div>
        <Breadcrumb separator='>'>
          <Breadcrumb.Item href='#/'>{t('home')}</Breadcrumb.Item>
          <Breadcrumb.Item>任务配置</Breadcrumb.Item>
          <Breadcrumb.Item href={'#/tasks/list'}>任务管理</Breadcrumb.Item>
          <Breadcrumb.Item>奖励列表(任务代码：{this.state.id})</Breadcrumb.Item>
        </Breadcrumb>

        <div className='main-header'>
          <div className='ant-form-inline'>
            <FormItem>
              <Input placeholder={'请输入奖励名称'}
                onChange = {this._onChange.bind(this, 'reward_name')}
                onKeyDown={this._handleKeyDown}/>
            </FormItem>
            <FormItem>
              <Button type='primary' onClick = {this._submit}>{'搜索'}</Button>
            </FormItem>
            <FormItem>
              <Button type='primary' onClick = {this._handleAdd.bind(this, '')}>{'新增'}</Button>
            </FormItem>
            <FormItem>
              <Button onClick={this._back} type='ghost'>{'返回'}</Button>
            </FormItem>
          </div>
          <div className='data-count'>
            {`共有${this.props.rewards.count || 0}条数据`}
          </div>
        </div>
        <List {...listProps}/>
        <Confirm visible={this.state.visible}
          title={'删除提示'}
          width='400'
          onOk={this._handleComfirm}
          onCancel={this._handleCancle}>
          <div style={{
            textAlign: 'center'
          }}>
            {'是否确定删除该选项'}
          </div>
        </Confirm>
      </div>
    )
  }

  _back = () => {
    this.props.history.pushState(null, 'tasks/list')
  }

  _handleComfirm = () => {
    let options = {
      uri: this.state.reId,
      success: {
        text: '删除成功',
        handler: () => {
          this._submit()
          this._hide()
        }
      }
    }
    this.props.delRewards(options)
  }

  _handleCancle = () => {
    this._hide()
  }

  _hide = () => {
    this.setState({
      visible: false
    })
  }
}
