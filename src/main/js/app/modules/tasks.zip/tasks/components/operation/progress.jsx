import React from 'react'

import { Progress } from 'antd'

const ProgressLine = Progress.Line

export default class extends React.Component {
  static propTypes = {
    percent: React.PropTypes.number
  }

  constructor (props) {
    super(props)
    this.state = {
      percent: props.percent
    }
  }

  componentDidMount () {
  }

  render () {
    return <ProgressLine percent={this.state.percent} />
  }

  setPercent = (percent) => {
    this.setState({
      percent: percent
    })
  }
}
