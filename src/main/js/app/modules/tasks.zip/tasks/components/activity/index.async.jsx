import '../static/styles/activity.scss'
import React from 'react'
import moment from 'moment'
import {connect} from 'react-redux'
import autobind from 'core-decorators/lib/autobind'
import {Link} from 'react-router'
import List from 'components/list/index'
import utils from 'utils'
import {  ACTIVITY_STATUS,
  ACTIVITY_PUSH,
   ACTIVITY_PRIORITY,
      ACTIVITY_NEWBIE,
      ACTIVITY_FOREVER} from '../../constants'
import {
  Button,
  Input,
  Modal,
  Form,
  Breadcrumb,
  Select,
  message
} from 'antd'
import actionCreators from 'modules/tasks/actions'
import {Confirm} from 'components/dialog/index'
const FormItem = Form.Item
const Option = Select.Option
import i18n from 'i18n'
import Add from './form'


function clone (origin) {
  return Object.assign({}, origin)
}

@connect(state => ({
  activity: state.activity
}), actionCreators)
export default class extends React.Component {
  constructor () {
    super()
    this.state = {
      addVisible: false,
      record:{},
      initVisible: false,
      dialogOkFn: () => {},
      dialogMsg: '',
      type: '',
      pageSize: utils.PAGE_SIZE, // 10
      currentPage: 1,
      activity_code: ''
    }
    this.t = i18n.getFixedT(null, 'tasks')

    this.formData = {
      type: '',
      name: ''
    }

    this.searchFormData = {}
  }

  handleInputChange (event) {
    this.formData.name = event.currentTarget.value
  }

  _hideOperation = () => {
    this.setState({addVisible: false})
  }

  _handleAdd = () => {
    this.setState({type: 'add', addVisible: true})
  }
  _handleEdit = (record) => {
    this.setState({
      type: 'edit',
      addVisible: true,
      record:record
    })
  }

  handleSelectChange (value) {
    if (value === 'select-all') {
        this.formData.type = ''
    }else {
        this.formData.type = value
    }
  }

  handleCloneWarn (record) {
    const t = i18n.getFixedT(null, 'tasks')
    this.setState({
      initVisible: true,
      dialogMsg: '是否要克隆名称【' + record.name + '】的活动?',
      dialogOkFn: this.handleClone.bind(this, record)
    })
  }

  handleClone (record) {
    const t = i18n.getFixedT(null, 'tasks')
    this.props.cloneActivity({
      data: {
        source: record.activity_code
      },
      success: {
        text: '操作成功',
        handler: res => {
          this.refs.list.reset()
          this.fetch({})
        }
      },
      error: {
        text:'操作失败',
        handler: err => {
          message.error( '操作失败' + ' ' + err.message)
        }
      }
    })
    this._closeDialog()
  }

  _closeDialog () {
    this.setState({initVisible: false})
  }

  _handleOperation = (type, formData, id) => {
    const {t} = this
    const _self = this
    if(type === 'edit'){
      this.props.putActivity({
        data:formData,
        success: {
          text: '操作成功',
          handler: _self.handleSubmit
        },
        error: {
          handler: function (data) {
            _self._hideOperation()
            message.error( '操作失败' + ',' + data.message , 3)
          }
        }
      })
    }else{
      this.props.putActivity({
        data: formData,
        success: {
          text: '操作成功',
          handler: _self.handleSubmit
        },
        error: {
          handler: function (data) {
            _self._hideOperation()
            message.error( '操作失败' + ',' + data.message , 3)
          }
        }
      })
    }
  }

  @autobind
  handleSubmit () {
    this._hideOperation()
    this.searchFormData = {}
    Object.keys(this.formData).map(function (key) {
      if (this.formData[key]) {
        this.searchFormData[key] = this.formData[key]
      }
    }.bind(this))
    let options = this.props.routeParams
    options.name = (this.searchFormData && this.searchFormData.name)
      ? this.searchFormData.name
      : ''
    options.type = (this.searchFormData && this.searchFormData.type)
        ? this.searchFormData.type
      : ''
    this.refs.list.reset()
    this.fetch(options)
  }


  fetch (options, restParams = {}) {
    const pack_name = options.name
    if (pack_name) {
      options.params = {
        ...options.params,
        $filter: 'packName like ' + pack_name
        // query: pack_name
      }
    } else {
      if(options.params){
        delete options.params.$filter
      }else{
        options.params = {
          ...options.params
        }
      }
    }

    // let type = options.type || (options.routeParams ? options.routeParams.type : '')
    // if (type) {
    //   delete options.params.$filter
    //   options.params.$filter =  'type eq ' + type
    // } else {
    //   delete options.params.$filter
    // }
    options.params.$limit = 10
    options.params.$count = true

    this.props.getActivityList({
      params: {
        ...options['params'],
        ...restParams.params
      }
    })

  }

  render () {
    const {t} = this
    let _this = this
    // let typeOptions = []
    // if (PACK_TYPE) {
    //     typeOptions.push(<Option value={'select-all'} key={'select-all'}  desc={'all所有'}> {'所有'}</Option>)
    //  for(let item in PACK_TYPE){
    //      typeOptions.push(<Option value={item} desc={PACK_TYPE[item] + item} key={item}>{PACK_TYPE[item]}</Option>)
    //  }
    // }
    const listProps = {
      data: this.props.activity,
      keyName: 'activity_code',
      // 参数
      restParams: {
        params: {}
      },
      // 操作栏
      operation: {
        title: t('operation'),
        dataIndex: '',
        width: 250,
        render: function (text, record) {
          return <span className='operate-group'>
               <span className='operate-item' onClick={_this._handleEdit.bind(_this,record)}>{'编辑'}</span>
               <span className='operate-item' onClick={_this.handleCloneWarn.bind(_this, record)}>{'克隆'}</span>
               {
                  record.status == '1' ?  <span className='operate-item' onClick={
                    ()=>{
                      _this.props.updownActivity({
                        replacement: {
                          activity_code:record.activity_code,
                          type: 'down'
                        },
                        success: {
                          text: '操作成功',
                          handler: _this.handleSubmit
                        },
                        error: {
                          handler: function (data) {
                            _this._hideOperation()
                            message.error( '操作失败' + ',' + data.message , 3)
                          }
                        }
                      })
                    }
                  }>{'下架'}</span> : <span className='operate-item' onClick={
                      ()=>{
                        _this.props.updownActivity({
                        replacement: {
                          activity_code:record.activity_code,
                          type: 'up'
                        },
                        success: {
                          text: '操作成功',
                          handler: _this.handleSubmit
                        },
                        error: {
                          handler: function (data) {
                            _this._hideOperation()
                            message.error( '操作失败' + ',' + data.message , 3)
                          }
                        }
                      })
                    }
                    }>{'上架'}</span>
               }
          </span>
        }
      },

      columnsData: [
        {
         title: '活动代码',
         dataIndex: 'activity_code',
         width: 180,
         render: function (text, record) {
           return (
           <span>{text}</span>
           )
         }
       },
        {
         title: '活动名称',
         dataIndex: 'name',
         width: 280,
         render: function (text, record) {
           return (
           <span>{text}</span>
           )
         }
       },
       {
        title: '状态',
        dataIndex: 'status',
        width: 180,
        render: function (text, record) {
          return (
          <span>{ACTIVITY_STATUS[ text ]}</span>
          )
        }
      },
       {
        title: '跳转链接',
        dataIndex: 'link',
        width: 280,
        render: function (text, record) {
          return (
          <span>{text}</span>
          )
        }
      }

     ],
      labelMap: {
        'activity_code': '活动代码',
        'name': '活动名称',
        'status': '状态',
        'link': '跳转链接'
      },
      inFilter: function (data) {
        let cloneData = clone(data)
        for (let key in cloneData) {

        }
        return cloneData
      },
      fetch: this.fetch.bind(this, this.props)
    }


    let addProps = {
      visible: this.state.addVisible,
      record: this.state.record,
      type: this.state.type,
      submit: this._handleOperation,
      hide: this._hideOperation
    }

    return (
      <div>
        <Breadcrumb separator='>'>
          <Breadcrumb.Item href='#/'>{t('home')}</Breadcrumb.Item>
          <Breadcrumb.Item>{'活动管理'}</Breadcrumb.Item>
          {/* <Breadcrumb.Item>{t('activityList')}</Breadcrumb.Item> */}
        </Breadcrumb>

        <div className='main-header'>
          <div className='ant-form-inline'>

            {/*<FormItem>
              <Input id='defaultInput' placeholder={t('packName')} onChange={this.handleInputChange.bind(this)}/>
            </FormItem>*/}
            {/* <FormItem>
            <Select  size='large'  placeholder={t('packType')}  style={{width: '180px'}}
              optionFilterProp='desc'  onChange={this.handleSelectChange.bind(this)}>
              {typeOptions}
            </Select>
          </FormItem> */}
            {/*<FormItem>
              <Button type='primary' onClick={this.handleSubmit.bind(this)}>{t('search')}</Button>
            </FormItem>*/}
            <div style={{ height: 24 }}> </div>

          </div>

          <div className='activity-data-count'>
            {t('totalCount', {
              total: this.props.activity.count || 0
            })}
          </div>
          <div className='activity-add'>
              <Button type='primary' onClick={this._handleAdd.bind(this)}>{ '新增' }</Button>
          </div>
        </div>
        <Confirm visible={this.state.initVisible} title={'提示'} width='700'
           onOk={this.state.dialogOkFn} onCancel={:: this._closeDialog}>
          <div style={{
            textAlign: 'center'
          }}>
            {this.state.dialogMsg}
          </div>
        </Confirm>
        <List ref='list' {...listProps}/>
        <Add {...addProps}/>
      </div>
    ) }
  }
