import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import utils from 'utils'
import { Button, Input, Form, Breadcrumb, Modal, Row, Col, Select } from 'antd'
import actionCreators from '../../actions'
import i18n from 'i18n'
import List from 'components/list/index'
import Global from './indexGlobal.async'
import Template from './indexTemplate.async'
import {TASK_TYPE} from '../../constants'
import {Link} from 'react-router'
const t = i18n.getFixedT(null, 'tasks')
const FormItem = Form.Item

@connect(state => ({
  tasks: state.tasks,
  taskslist: state.taskslist
}), actionCreators)
export default class extends React.Component {
  static propTypes = {
    getTaskList: PropTypes.func,
    getTaskListCode: PropTypes.func,
    updateTask: PropTypes.func,
    cloneTask: PropTypes.func,
    history: PropTypes.object,
    taskslist: PropTypes.object,
    tasks: PropTypes.object
  }
  constructor () {
    super()
    this.state = {
      pageSize: utils.PAGE_SIZE,
      currentPage: 1,
      task_name: undefined,
      list_code: undefined,
      task_code: undefined,
      task_type: undefined
    }
  }

  componentDidMount () {
    this.props.getTaskListCode()
  }

  _getList = (options, page) => {
    this.state.currentPage = page
    let params = {
      ...options.params
    }
    let $filter = []
    if (this.state.task_name) {
      $filter.push(`taskName like ${this.state.task_name}`)
    }
    if (this.state.task_code) {
      $filter.push(`taskCode eq ${this.state.task_code}`)
    }
    if (this.state.list_code) {
      $filter.push(`listCode eq ${this.state.list_code}`)
    }
    if (this.state.task_type) {
      $filter.push(`taskType eq ${this.state.task_type}`)
    }
    params.$filter = $filter.join(' | ')
    delete params.$orderby
    this.props.getTaskList({
      params: params
    })
  }

  _onChange = (field, e) => {
    this.setState({
      [field]: e.target.value.trim()
    })
  }

  _onSelectChange = (value) => {
    this.setState({
      list_code: value
    })
  }
  _onSelectTypeChange = (value) => {
    if(value !== 'all' ){
      this.setState({
        task_type: value
      })
    }else{
      this.setState({
        task_type: 0
      })
    }
  }

  _submit = () => {
    let options = {}
    options.params = {
      $limit: this.state.pageSize,
      $count: true,
      $offset: 0
    }
    this._getList(options, 1)
  }

  _handleUpdate = (record) => {
    let options = {
      uri: record.task_code,
      data: {
        status: !record.status
      },
      list: {
        params: this._getParams(1)
      },
      success: {
        text: record.status ? '停用成功' : '启用成功',
        handler: () => {
          this.setState({
            currentPage: 1
          })
        }
      }
    }
    this.props.updateTask(options)
  }

  _handRewardsList = (id) => {
    this.props.history.pushState(null, 'tasks/rewards/' + id)
  }

  _addTasks = (record) => {
    let isClone = record.isClone || ''
    if (record && !record.is_simple) {
      let id = record.task_code || ''
      this.props.history.pushState(null, 'tasks/operation/' + id + '/' + isClone)
    } else {
      let id = record && record.task_code
      this.props.history.pushState(null, 'tasks/operationS/' + id + '/' + isClone)
    }
  }

  _getParams = (currentPage) => {
    let params = {
      $limit: this.state.pageSize,
      $count: true,
      $offset: ((currentPage || 1) - 1) * this.state.pageSize
    }
    if (this.state.task_name) {
      params.$filter = `taskName like ${this.state.task_name}`
    }
    return params
  }

  _handleClone = (id) => {
    let options = {
      data: {
        source: id
      },
      success: {
        text: '克隆成功',
        handler: () => {
          this.setState({
            currentPage: 1
          })
        }
      },
      list: {
        params: this._getParams(1)
      }
    }
    this.props.cloneTask(options)
  }

  _handleKeyDown = (e) => {
    if (e.keyCode === 13) {
      this._submit()
    }
  }

  _cancel = () => {
    this.setState({
      visible: false
    })
    sessionStorage.removeItem('show')
  }

  _goto = () => {
    sessionStorage.removeItem('show')
    this._handRewardsList(sessionStorage.getItem('id'))
  }

  render () {
    const _self = this
    let listProps = {
      // 数据
      data: this.props.tasks,
      currentPage: this.state.currentPage,
      // 参数
      restParams: {
        params: {
          $limit: this.state.pageSize,
          $count: true
        }
      },
      operation: {
        title: t('operation'),
        dataIndex: '',
        render: function (text, record) {
          return <span className='operate-group'>
            <span className='operate-item' onClick={_self._addTasks.bind(this, record)}>
              {'编辑'}
            </span>
            <span className='operate-item' onClick={_self._handleUpdate.bind(this, record)}>
              {record.status ? '停用 ' : '启用'}
            </span>
            <span className='operate-item' onClick={_self._handRewardsList.bind(this, record.task_code)}>
              {'奖励列表'}
            </span>
            <Link className='operate-item' to={'log/execute/' + record['task_code']}>{'查看任务完成情况'}</Link>
            <span className='operate-item' onClick={_self._addTasks.bind(this, {...record, isClone: true})}>
              {'克隆'}
            </span>
          </span>
        }
      },
      columnsData: [
        {
          title: '任务名称（任务代码）',
          width: '30em',
          dataIndex: 'task_code',
          render: function (text, record) {
            return <span className='ellipsis max-width-30' title={text}>{record.task_name + '(' + text + ')'}</span>
          }
        }, {
          title: '是否简单任务',
          dataIndex: 'is_simple',
          render: function (text, record) {
            return (
                    <span className='ellipsis max-width-5' title={text}>{text ? '是' : '否'}</span>
                   )
          }
        },{
          title: t('taskType'),
          dataIndex: 'task_type',
          width: 120,
          render: function (text, record) {
            return (
              <span>{TASK_TYPE[text]} </span>
            )
          }
        },{
          title: '任务周期',
          dataIndex: 'cycle',
          render: function (text, record) {
            let msg = '一次性'
            switch (text) {
              case 'DAY':
                msg = '天'
                break
              case 'WEEK':
                msg = '周'
                break
              case 'MONTH':
                msg = '月'
                break
              case 'CUSTOM':
                msg = '自定义每日'
                break
              case 'YEAR':
                msg = '年'
                break
            }
            return (
                    <span className='ellipsis max-width-5' title={text}>{msg}</span>
                   )
          }
        }, {
          title: '允许延期',
          dataIndex: 'auto_delay',
          render: function (text, record) {
            let msg = text ? '允许延期' : '不可延期'
            return (
                    <span className='ellipsis max-width-5'>{msg}</span>
                   )
          }
        }, {
          title: '列表代码',
          dataIndex: 'list_code',
          render: function (text, record) {
            return (
                    <span className='ellipsis max-width-5'>{text}</span>
                   )
          }
        }
      ],
      labelMap: {
        task_code: '任务代码',
        is_simple: '是否简单任务',
        task_type: '任务类型',
        cycle: '任务周期',
        auto_delay: '允许延期',
        list_code: '列表代码'
      },
      inFilter: function (data) {
        data['key'] = data['task_code']
        return data
      },
      fetch: _self._getList
    }
    let options = []
    if (this.props.taskslist && this.props.taskslist.items) {
      options = this.props.taskslist.items
    }

    let taskTypeOptions = []
    // taskTypeOptions.push( <Option value={'select-all'}  key={'select-all'} >所有</Option>  )
    for (let index in TASK_TYPE) {
      taskTypeOptions.push(
        <Option value={`${index}`}  key={index} > {TASK_TYPE[index]} </Option>
      )
    }
    return (
      <div>
        <Breadcrumb separator='>'>
          <Breadcrumb.Item href='#/'>{t('home')}</Breadcrumb.Item>
          <Breadcrumb.Item>任务配置</Breadcrumb.Item>
          <Breadcrumb.Item>任务管理</Breadcrumb.Item>
        </Breadcrumb>

        <div className='main-header'>
          <div className='ant-form-inline'>
            <FormItem>
              <Input placeholder={'请输入任务代码'}
              onChange = {this._onChange.bind(this, 'task_code')}
              onKeyDown={this._handleKeyDown}/>
            </FormItem>
            <FormItem>
              <Input placeholder={'请输入任务名称'}
              onChange = {this._onChange.bind(this, 'task_name')}
              onKeyDown={this._handleKeyDown}/>
            </FormItem>
            <Form.Item>
              <Select placeholder='请选择状态'
                defaultValue={0}
                style={{width: '180px'}}
                onChange={this._onSelectChange}>
                <Option value={0}>{'所有'}</Option>
                {options.map((item) => {
                  return <Option value={item.list_code} key={item.list_code}>{item.list_code}</Option>
                })}
              </Select>
            </Form.Item>
            <FormItem>
            <Select  defaultValue={'all'}  placeholder={t('taskType')}  style={{width: '180px'}} onChange={this._onSelectTypeChange}>
              <Option value={'all'}>{'所有'}</Option>
              {taskTypeOptions}
            </Select>
          </FormItem>
            <FormItem>
              <Button type='primary' onClick = {this._submit}>{'搜索'}</Button>
            </FormItem>
            <FormItem>
              <Template gotoTasks = {this._addTasks}/>
            </FormItem>
            <FormItem>
              <Global getTasks = {this._submit}/>
            </FormItem>
            <FormItem>
              <Button type='primary' onClick = {this._addTasks.bind(this, '')}>{'新增简单任务'}</Button>
            </FormItem>
          </div>
          <div className='data-count'>
            {`共有${this.props.tasks.count || 0}条数据`}
          </div>
        </div>
        <List {...listProps}/>
        <Modal title={'提示'}
          className='task-dialog'
          visible={sessionStorage.getItem('show') === 'yes'}
          width = '400px'
          footer={[
            <Row key={1}>
              <Col span='24' style={{textAlign: 'center'}}>
                <Button type='ghost' size='large'
                    style={{marginRight: 30}}
                    onClick={this._cancel}>
                    {t('cancel')}
                </Button>
                <Button type='primary' size='large'
                      onClick={this._goto}>
                  {'开始配置'}
                </Button>
              </Col>
            </Row>
          ]}
          onCancel={this._cancel}>
          <div className='dialog-content'>
            {sessionStorage.getItem('msg')}
          </div>
        </Modal>
      </div>
    )
  }
}
