export function objectIsEqual (obj1, obj2) {
  const aProps = Object.getOwnPropertyNames(obj1)
  const bProps = Object.getOwnPropertyNames(obj2)
  if (aProps.length !== bProps.length) {
    return false
  }
  for (let i = 0; i < aProps.length; i++) {
    const propName = aProps[i]
    if (obj1[propName] && obj1[propName].constructor === Object) {
      if (obj2[propName] && !objectIsEqual(obj1[propName], obj2[propName])) {
        return false
      }
    } else {
      if (obj1[propName] !== obj2[propName]) {
        return false
      }
    }
  }
  return true
}
