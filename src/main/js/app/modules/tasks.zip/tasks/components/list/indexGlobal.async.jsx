import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import utils from 'utils'
import { Button, Input, Form, Modal, Row, Col, message } from 'antd'
import actionCreators from '../../actions'
import i18n from 'i18n'
import List from 'components/list/index'

const t = i18n.getFixedT(null, 'log')
const FormItem = Form.Item

@connect(state => ({
  tasks: state.tasks
}), actionCreators)
export default class extends React.Component {
  static propTypes = {
    getGlobalTaskList: PropTypes.func,
    cloneGlobalTaskList: PropTypes.func,
    getTaskList: PropTypes.func,
    history: PropTypes.object,
    tasks: PropTypes.object
  }
  constructor (props) {
    super(props)
    this.state = {
      visible: false,
      pageSize: utils.PAGE_SIZE,
      currentPage: 1,
      selectedRowKeys: [],
      task_name: undefined
    }
  }

  componentDidMount () {

  }

  _getList = (options, page) => {
    this.state.currentPage = page
    let params = {
      ...options.params
    }
    if (this.state.task_name) {
      params.$filter = `taskName like ${this.state.task_name}`
    }
    delete params.$orderby
    this.props.getGlobalTaskList({
      params: params
    })
  }

  _onChange = (field, e) => {
    this.setState({
      [field]: e.target.value.trim()
    })
  }

  _submit = () => {
    let options = {}
    options.params = {
      $limit: this.state.pageSize,
      $count: true,
      $offset: 0
    }
    this._getList(options, 1)
  }

  _clone = () => {
    const that = this
    if (this.state.selectedRowKeys.length === 0) {
      message.error('请选择全局任务')
      return
    }
    let options = {
      data: {
        items: this.state.selectedRowKeys
      },
      success: {
        text: '新增成功',
        handler: () => {
          that._cancel()
          that.props.getTasks()
        }
      }
    }
    this.props.cloneGlobalTaskList(options)
  }

  _addGlobal = () => {
    this._submit()
    this.setState({
      visible: true
    })
  }

  _cancel = () => {
    this.setState({
      visible: false,
      currentPage: 1,
      selectedRowKeys: [],
      task_name: undefined
    })
  }

  _handleKeyDown = (e) => {
    if (e.keyCode === 13) {
      this._submit()
    }
  }

  render () {
    const _self = this
    let listProps = {
      // 数据
      data: this.props.tasks.global,
      currentPage: this.state.currentPage,
      // 参数
      restParams: {
        params: {
          $limit: this.state.pageSize,
          $count: true
        }
      },
      columnsData: [
        {
          title: '任务名称',
          dataIndex: 'task_name',
          render: function (text, record) {
            return <span className='ellipsis max-width-10' title={text}>{text}</span>
          }
        },
        {
          title: '任务代码',
          dataIndex: 'task_code',
          render: function (text, record) {
            return <span className='ellipsis max-width-10' title={text}>{text}</span>
          }
        },
        {
          title: '任务描述',
          dataIndex: 'desc',
          render: function (text, record) {
            return <span className='ellipsis max-width-10' title={text}>{text}</span>
          }
        }
      ],
      labelMap: {
        task_name: '任务名称',
        task_code: '任务代码',
        desc: '任务描述'
      },
      inFilter: function (data) {
        data['key'] = data['task_code']
        return data
      },
      rowSelection: {
        getCheckboxProps (record) {
          let checked = false
          for (let i = 0, len = _self.state.selectedRowKeys.length; i < len; i++) {
            if (record.task_code === _self.state.selectedRowKeys[i]) {
              checked = true
              break
            }
          }
          return {
            defaultChecked: checked // 配置默认勾选的列
          }
        },
        onSelect: (record, selected, selectedRows) => {
          if (selected) {
            _self.state.selectedRowKeys.push(record.task_code)
            _self.state.selectedRowKeys = Array.from(new Set(_self.state.selectedRowKeys))
          } else {
            let selectedRowKeys = _self.state.selectedRowKeys
            for (let i = 0; i < selectedRowKeys.length; i++) {
              if (selectedRowKeys[i] === record.task_code) {
                selectedRowKeys.splice(i, 1)
                break
              }
            }
          }
        },
        onSelectAll: (selected, selectedRows) => {
          if (selected) {
            for (let selectedRow of selectedRows) {
              _self.state.selectedRowKeys.push(selectedRow.task_code)
            }
            _self.state.selectedRowKeys = Array.from(new Set(_self.state.selectedRowKeys))
          } else {
            let records = _self.props.tasks.global.items
            let selectedRowKeys = _self.state.selectedRowKeys
            for (let j = 0; j < records.length; j++) {
              for (let i = 0; i < selectedRowKeys.length; i++) {
                if (selectedRowKeys[i] === records[j].task_code) {
                  selectedRowKeys.splice(i, 1)
                  break
                }
              }
            }
          }
        }
      },
      fetch: _self._getList
    }
    return (
      <div>
        <Button type='primary' onClick = {this._addGlobal}>{'添加全局任务'}</Button>
        <Modal title={'添加全局任务'}
          className = 'task_modal'
          visible={this.state.visible}
          width = '600px'
          footer={[
            <Row key={1}>
              <Col span='24' style={{textAlign: 'center'}}>
                <Button type='ghost' size='large'
                    style={{marginRight: 30}}
                    onClick={this._cancel}>
                    {t('cancel')}
                </Button>
                <Button type='primary' size='large'
                      onClick={this._clone}>
                  {t('confirm')}
                </Button>
              </Col>
            </Row>
          ]}
          onCancel={this._cancel}>

          <div className='main-header'>
            <div className='ant-form-inline'>
              <FormItem>
                <Input placeholder={'请输入任务名称'}
                onChange = {this._onChange.bind(this, 'task_name')}
                value={this.state.task_name}
                onKeyDown={this._handleKeyDown}/>
              </FormItem>
              <FormItem>
                <Button type='primary' onClick = {this._submit}>{'搜索'}</Button>
              </FormItem>
            </div>
            <div className='data-count'>
              {`共有${(this.props.tasks.global && this.props.tasks.global.count) || 0}条数据`}
            </div>
          </div>
          <List {...listProps}/>
        </Modal>
      </div>
    )
  }
}
