import React, { PropTypes } from 'react'
import i18n from 'i18n'
import ELeaning from '../../utils/eLeaning'
import { Confirm } from 'components/dialog/index'
import ConfigLogs from '@sdp.nd/social/libs/jsonDiff'
import utils from 'utils'
import {
  // TASK_STATUS,
  TASK_SHOW_PROGRESS,
  TASK_CYCLE,
  TASK_PRIORITY,
  TASK_AUTODELAY,
  TASK_JOIN_STATUS,
  TASK_TYPE,
  TASK_PUSHIM,
  TASK_RESTART_INTERVAL,
  TASK_RESTART_TIMES,
  NULL_TIME,
  WEEK,
  ELEARNING_URL,
  RULE_WAY
} from '../../constants'
import { Form, Input, Validation, Button, DatePicker, Radio, Select, Row, Col,Checkbox,Tag,  TimePicker , message, InputNumber } from 'antd'
import { mixin } from 'core-decorators'
import moment from 'moment'
const InputGroup = Input.Group
const FormItem = Form.Item
const RadioGroup = Radio.Group
const CheckboxGroup = Checkbox.Group
const Option = Select.Option
const Validator = Validation.Validator
const cx = (classNames) => {
  if (typeof classNames === 'object') {
    return Object.keys(classNames).filter(function (className) {
      return classNames[className]
    }).join(' ')
  } else {
    return Array.prototype.join.call(arguments, ' ')
  }
}
const eLeaning = new ELeaning()
const configLogs = new ConfigLogs()

const keys = {
  list_code: '所属任务列表',
  task_type: '任务类型',
  push: '是否推送IM消息',
  start_time2: '下发时间段开始',
  end_time: '下发时间段结束',
  start_num: '下发日期开始',
  end_num: '下发日期结束',
  start_date: '下发日期开始',
  end_date: '下发日期结束',
  week_days: '有效日期',
  restart_times: '重启次数',
  restart_times_zdy: '重启次数',
  restart_interval: '重启间隔时间',
  restart_interval_zdy: '重启间隔时间',
  task_name: '任务名称',
  desc: '任务描述',
  priority: '任务优先级',
  red_remind: '是否红点统计',
  cycle: '任务周期',
  start_time: '任务开始日期',
  task_days: '完成时限',
  unit: '完成时限',
  task_tag: '任务标签',
  max_schedule: '进度上限',
  requirement: '完成条件描述',
  business_id: '接入业务',
  link: '客户端跳转地址',
  web_link: 'PC端跳转地址',
  auto_delay: '是否允许延期',
  delay_days: '最大延期天数',
  param: '业务参数',
  tenant_status: '接入状态'
}

@mixin(Validation.FieldMixin)
export default class extends React.Component {
  static propTypes = {
    id: PropTypes.string,
    clone: PropTypes.string,
    postSimpletask: PropTypes.func,
    patchTask: PropTypes.func,
    postGlobalTask: PropTypes.func,
    postTask: PropTypes.func,
    taskslist: PropTypes.object,
    statusType: PropTypes.object,
    presetTimeTask: PropTypes.object,
    history: PropTypes.object
  }

  static defaultProps = {
  }

  constructor () {
    super()
    const formData = {}
    let time_range = formData.time_range
    let week_days = []
    if( time_range && time_range.week_days ){
        time_range.week_days.split(',').map(
          (item,index)=>{
             week_days.push(WEEK[item])
        })
    }else{
      week_days = Object.values(WEEK).slice(0,5)
    }
    formData.restart_interval =  [0].indexOf(+formData.restart_interval / 60) > -1 ?  '0' : (+formData.restart_interval / 60) ?  (+formData.restart_interval / 60)  : '0'
    this.business = {}
    this.state = {
      datas: {},
      visible: false,
      visibleComfire: false,
      status: {
        list_code: {},
        task_type: {},
        push: {},
        random_date:{},
        random_time:{},
        random_num: {},
        week_days: {},
        restart_times: {},
        restart_interval: {},
        task_code: {},
        task_name: {},
        desc: {},
        priority: {},
        red_remind: {},
        cycle: {},
        start_time: {},
        end_times: {},
        task_days: {},
        unit: {},
        task_tag: {},
        max_schedule: {},
        requirement: {},
        business_id: {},
        link: {},
        web_link: {},
        auto_delay: {},
        param: {},
        tenant_status: {},
        delay_days: {},
        rule_way:  {},
        statis_way:  {},
        task_linked_type: {},
        statis_source:  {},
        date_config_id:  {},
        status_type:  {},
      },
      formData: {
        rule_way: '1',
        status_type: undefined,
        list_code: undefined,
        task_type: '0',
        push: true,
        start_time2: time_range ? time_range.start_time2 :'00:00',
        end_time: time_range ? time_range.end_time :'23:50',
        start_num: time_range ? time_range.start_num :1,
        end_num: time_range ? time_range.end_num :31,
        start_date:time_range ? new Date(time_range.start_date) : new Date(),
        end_date:time_range ? new Date(time_range.end_date) : new Date(),
        week_days: week_days,
        restart_times: '0',
        restart_times_zdy: [0,-1].indexOf(+formData.restart_times ? +formData.restart_times : 0) > -1 ? +formData.restart_times : 'ZDY',
        restart_interval: '0',
        restart_interval_zdy: [0].indexOf(+formData.restart_interval / 60) > -1 ? (+formData.restart_interval / 60) ? (+formData.restart_interval / 60)  : '0' : 'ZDY',
        task_code: undefined,
        task_name: undefined,
        desc: undefined,
        priority: '2',
        red_remind: true,
        cycle: undefined,
        start_time: moment().toDate(),
        end_times: undefined,
        task_days: 1,
        unit: 'DAY',
        task_tag: '新手任务',
        max_schedule: undefined,
        requirement: undefined,
        business_id: undefined,
        link: undefined,
        web_link: undefined,
        auto_delay: undefined,
        task_linked_type: 'disOrder',
        delay_days: 7,
        param: undefined,
        tenant_status: true,
        statis_way: undefined,
        statis_source: undefined,
        date_config_id: undefined,
        status: false
      }
    }
  }

  t = i18n.getFixedT(null, 'tasks')

  componentDidMount () {
    // e-leaning 页面加载完成
    eLeaning.on('loaded', this._init)

    // e-leaning 页面选完课程/培训
    eLeaning.on('set item', this._getData)
  }

  _init = (data) => {
    let that = this
    // [仅任务编辑时调用] 在这里对 e-leaning 初始化选中课程/培训，即：eLeaning.setItem({...})
    data.code = that.state.formData.param
    data.code && eLeaning.setItem({...data})
  }

  _getData = (data) => {
    if (data.code && data.name) {
      let that = this
      that.state.formData.param = data.code
      that.state.formData.link = data.cmp_link
      that.state.formData.web_link = this._setSSO(data.web_link)
      that.state.elearnName = data.name
      that.setState({
        visible: false,
        visibleComfire: true,
        formData: that.state.formData
      })
      this.refs.validation.forceValidate(['param'])
      if (data.cmp_link) {
        this.refs.validation.forceValidate(['link'])
      }
    }
  }

  _setSSO = (link) => {
    if (!link || this.business.business_url.indexOf(ELEARNING_URL) === -1) {
      return link
    }
    if (link.indexOf('?') !== -1) {
      link += '&__mac={mac_token}'
    } else {
      link += '?__mac={mac_token}'
    }
    return link
  }

  componentWillUnmount () {
    eLeaning.removeListener('set item', this._getData)
    eLeaning.removeListener('loaded', this._init)
  }

  _chearnElearning = () => {
    this.state.formData.param = ''
    this.setState({
      formData: this.state.formData
    })
  }

  /**
   * 表单验证
   */
  _renderValidateStyle = (item) => {
    const status = this.state.status

    return cx({
      'error': status[item].errors,
      'validating': status[item].isValidating,
      'tip': ''
    })
  }

  setFormdatas (data) {
    if( !data){
       message.info('请先进入任务列表页面',3)
       return
    }
    const formData = this.state.formData
    let time_range = data.time_range || {}
    let week_days = []
    if( time_range && time_range.week_days ){
        time_range.week_days.split(',').map(
          (item,index)=>{
             week_days.push(WEEK[item])
        })
  }else{
    week_days = Object.values(WEEK).slice(0,5)
  }

  let restart_interval =  [0].indexOf(+data.restart_interval / 60) > -1 ?  '0' : (+data.restart_interval / 60) ?  (+data.restart_interval / 60)  : '0'
  let restart_times_zdy = [0,-1].indexOf(+data.restart_times ? +data.restart_times : 0) > -1 ? +data.restart_times : 'ZDY'
  let restart_interval_zdy = [0].indexOf(+data.restart_interval / 60) > -1 ? (+data.restart_interval / 60) ? (+data.restart_interval / 60)  : '0' : 'ZDY'

    Object.keys(data).map((key) => {
      formData[key] = data[key]
    })
    formData.task_tag = formData.task_tag || '新手任务'
    formData.start_time = data.start_time ? moment(data.start_time).toDate() : ''
    formData.end_times = data.end_time ? moment(data.end_time).toDate() : ''
    if (data.tenant_join) {
      formData.business_id = data.tenant_join.business_id
      formData.param = data.tenant_join.param
      formData.tenant_status = data.tenant_join.status
    } else {
      formData.tenant_status = true
    }
    const datas = {
      ...formData,
      task_type: formData.task_type ? formData.task_type : '0',
      task_linked_type: formData.task_linked_type || 'disOrder',
      push: formData.push !== null ? formData.push : 'true',
      restart_interval: restart_interval,
      restart_times_zdy: restart_times_zdy,
      restart_interval_zdy: restart_interval_zdy,
      start_time2: time_range && time_range.start_time ? time_range.start_time :'00:00',
      end_time: time_range && time_range.end_time ? time_range.end_time :'23:50',
      start_num: time_range && time_range.start_num ? time_range.start_num :1,
      end_num: time_range && time_range.end_num ? time_range.end_num :31,
      start_date: time_range && time_range.start_date ? new Date(time_range.start_date) : new Date(),
      end_date: time_range && time_range.end_date ? new Date(time_range.end_date) : new Date(),
      week_days: week_days
    }
    this.state.datas = {
      ...datas
    }
    this.setState({
      formData: {
        ...datas
      }
    })
  }

  _handleSubmit = (flag) => {
    const { t } = this
    const validation = this.refs.validation
    validation.validate((valid) => {
      if (!valid) {
        let formStatus = this.state.status
        for (let index in formStatus) {
          let errors = formStatus[index].errors
          if (errors && errors.length > 0) {
            message.info('请保证所有字段验证合格 , ' + errors, 4)
            break
          }
        }
        return
      }
      // else {
        let formData = {}
        Object.keys(this.state.formData).map((key) => {
          formData[key] = this.state.formData[key]
        })
        if (formData.start_time) {
          formData.start_time = this._getDate(formData.start_time)
        } else {
          formData.start_time = null
        }
        formData.status = flag

      formData.tenant_join = {}
      formData.tenant_join.business_id = formData.business_id
      formData.tenant_join.param = formData.param
      formData.tenant_join.status = formData.tenant_status


        //随机任务
        let time_range = {}
         time_range.start_date = moment(formData.start_date).format('YYYY-MM-DD')
         time_range.end_date = moment(formData.end_date).format('YYYY-MM-DD')
         time_range.start_time = formData.start_time2 // KEY 结构同名
         time_range.end_time = formData.end_time
         time_range.start_num = formData.start_num
         time_range.end_num = formData.end_num
         let weekValues = formData.week_days ||  []
         let week_days = []
         weekValues.map(
           (item,index) => {
               let idx =  Object.values(WEEK).indexOf(item) + 1
               if(idx > 0){
                   week_days.push(idx)
               }
           }
         )
         let afterSort = week_days.sort()
         if( formData.cycle === 'CUSTOM'  || formData.cycle === 'WEEK'){
           week_days = week_days.join(',')
         }else{
           week_days = ''
         }
         time_range.week_days = week_days ? week_days  : ''
         formData.time_range = time_range || {}
         let totalResIn = formData.restart_interval * 60 || 0
         formData.restart_interval = totalResIn
        //随机任务
        console.log('表单数据', formData)

        // 混合业务判断原料
        const { cycle, task_type, restart_interval, restart_times, unit ,task_days} = formData
        const { start_num,end_num,start_date,end_date,start_time,end_time } = formData.time_range
        // 代表随机任务
        if( task_type == '1' ){
            // 算任务 完成时间
            let  startTime2  = start_time
            let  endTime = end_time
            if(startTime2 && endTime ){
              // let s = moment([2007,0,29,startTime2.split(':')[0],startTime2.split(':')[1]])
              let e = moment([2007,0,29,endTime.split(':')[0],endTime.split(':')[1]])
              // let minutes = e.diff(s,'minutes')  // 1返回相差的分钟数
              let minutes = (+task_days && ['DAY','HOUR','MINUTE'].indexOf(unit) != -1 )  ?  +task_days : 0 //  5.24 随机任务完成时限 校验变化
              if(minutes > 0){
                // 算任务完成时限
                if(unit === 'DAY'){
                  minutes = minutes * 24 * 60
                }else if(unit === 'HOUR'){
                  minutes = minutes * 60
                }
                 // 算任务截止时间 和 周期时间
                 let endMinutes  = e.diff( moment([2007,0,29,0,0]), 'minutes')
                 let maxTime = 23.5
                 if(cycle === 'MONTH'){
                    endMinutes += end_num > 0  ? (end_num - 1) * 24 * 60 : 0 //
                    maxTime = 31 * 24 *60
                 }else if(cycle === 'ONCE'){
                  //  let daysDiff = moment(end_date).diff( moment(start_date), 'days')
                  //  maxTime =  (+daysDiff  - 1)  <= 0 ? 23.5 :  (+daysDiff  - 1)  * 24
                 }else if(cycle === 'WEEK'){
                  endMinutes +=  afterSort.length > 0  ? (afterSort[afterSort.length - 1] - 1) * 24 * 60 : 0 // 周取最大的 已经排序 周天就是7
                  maxTime =   7 * 24 * 60
                 }else if(cycle === 'DAY'){
                   endMinutes += 0  //还是当天的
                   maxTime  = 24 * 60
                 }else if(cycle === 'CUSTOM'){
                   endMinutes += 0  //还是当天的
                   maxTime  = 24 * 60
                 }
                  // 定义 预留时间
                 let remainTime =  0.5 * 60
                 if( +restart_times >= 0  && cycle !== 'ONCE'){  // 一次性不验证
                   // do calculate
                  let time =  endMinutes  +  (  (+restart_times > 0 ? +restart_interval : 0)  +  minutes )  *  ( +restart_times == 0 ? 1 : +restart_times  )  + remainTime // 任务截止时间 + （任务完成时间 + 重启间隔时间）x 重启次数（不重启 用1算）  + 预留时间
                  console.log(`任务截止时间${endMinutes} + (任务完成时间${minutes} + 重启间隔时间${ +restart_times > 0 ? +restart_interval : 0}) x 重启次数${+restart_times == 0 ? 1:+restart_times }  + 预留时间${remainTime} ` )
                  // console.log('任务截止时间' , endMinutes )
                  // console.log('重启次数' , +restart_times )
                  // console.log('重启间隔时间' , +restart_times > 0 ? +restart_interval : 0 )
                  // console.log('预留时间' , +remainTime )
                  console.log('本周期时限' , +maxTime )
                  console.log('算好的时间' , +time )
                  let error;
                  error = time >= maxTime ? '请合理配置随机任务 【任务截止时间 + (任务完成时间 + 重启间隔时间) x 重启次数 + 预留时间 < 本周期时间】'  : undefined
                  if(error){
                    message.info(error , 8)
                    return
                  }
                }

              }else{
                message.info('请根据【周期】合理配置【完成时限】' , 5)
                return
              }
            }
        }

        if (formData.end_times) {
          formData.end_time = this._getDate(formData.end_times)
        } else {
          formData.end_time = undefined
        }
        let options = {
          data: formData,
          success: {
            text: '保存成功',
            handler: (data) => {
              const config_app_id = '养成管理后台.任务配置.任务管理.修改任务'
              const config_id = data.task_code || data.task.task_code
              const content = this._handleComp(false)
              configLogs.saveLog(utils.CONFIG_LOGS, config_app_id, config_id, content, utils.auth.getAuth().user_id, this._handleBack)
            }
          },
          error: {
            text: '保存失败',
            handler: () => {
              if (formData.start_time) {
                formData.start_time = moment(formData.start_time).toDate()
              }
            }
          }
        }
        if (this.props.id && !this.props.clone) {
          options.uri = this.props.id
          this.props.patchTask(options)
        } else if (this.props.clone) {
          this.props.postTask(options)
        } else {
          this.props.postGlobalTask(options)
        }
      // }
    })
  }

  //
  _handleComp = (flag) => {
    this.state.formData.start_date = moment(this.state.formData.start_date).format('YYYY-MM-DD')
    this.state.formData.end_date = moment(this.state.formData.end_date).format('YYYY-MM-DD')
    this.state.formData.rule_way = this.state.formData.rule_way || 1
    if (this.props.id && !this.props.clone) {
      this.state.datas.start_date = moment(this.state.datas.start_date).format('YYYY-MM-DD')
      this.state.datas.end_date = moment(this.state.datas.end_date).format('YYYY-MM-DD')
      this.state.datas.rule_way = this.state.datas.rule_way || 1
      Object.keys(this.state.datas).map(key => {
        if (this.state.datas[key] + '' === this.state.formData[key] + '') {
          this.state.datas[key] = this.state.formData[key]
        }
      })
    } else {
      this.state.datas = {}
    }
    return configLogs.showDiff(this.state.datas, this.state.formData, keys, flag)
  }
  //
  _handleShowLogs = () => {
    const config_app_id = '养成管理后台.任务配置.任务管理.修改任务'
    const config_id = this.state.formData.task_code
    configLogs.showLogs(utils.CONFIG_LOGS, config_app_id, config_id, keys)
  }

  // 获取日期
  _getDate = (value) => {
    let date = moment(value.getTime()).toDate()
    return date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2) + 'T' + ('0' + date.getHours()).slice(-2) +
    ':' + ('0' + date.getMinutes()).slice(-2) + ':' + ('0' + date.getSeconds()).slice(-2) + '.000+0800'
  }

  _handleBack = () => {
    this.props.history.pushState(null, 'tasks/list')
  }

  _checkName = (rule, value, callback) => {
    if (!value || value.length === 0) {
      callback()
    } else if (value.trim().length > 50) {
      callback('字符长度不能超过50')
    } else {
      callback()
    }
  }

  _checkDesc = (rule, value, callback) => {
    if (!value || value.length === 0) {
      callback()
    } else if (value.trim().length > 1000) {
      callback('字符长度不能超过1000')
    } else {
      callback()
    }
  }

  _checksChedule = (rule, value, callback) => {
    let req = /^\+?[1-9][0-9]*$/
    if (!value || value.trim().length === 0) {
      callback()
    } else if (!req.test(value.trim())) {
      callback('请输入正整数')
    } else if (parseInt(value.trim(), 10) > 100) {
      callback('不能大于100')
    } else {
      callback()
    }
  }

  _checksTaskdays = (rule, value, callback) => {
    let req = /^\+?[1-9][0-9]*$/
    if (!value || value.trim().length === 0) {
      callback()
    } else if (!req.test(value.trim())) {
      callback('请输入正整数')
    } else if (this.state.formData.unit === 'MINUTE' && (parseInt(value + ''.trim(), 10) !== 30 && parseInt(value + ''.trim(), 10) !== 45 && parseInt(value + ''.trim(), 10) !== 60)) {
      callback('只允许输入：【30,45,60】')
    } else if (parseInt(value.trim(), 10) > 1000) {
      callback('不能大于1000')
    } else {
      callback()
    }
  }

  _checkLink = (rule, value, callback) => {
    let req = /^(http|local|https|im|cmp|react):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?$/
    if (!value || value.trim().length === 0) {
      callback()
    } else if (!req.test(value.trim())) {
      // callback('请输入正确的URL地址,协议为http/https/im/cmp/local/react中的一种')
      callback()
    } else {
      callback()
    }
  }

  _checkDelayDays = (rule, value, callback) => {
    let req = /^\+?[1-9][0-9]*$/
    if (!value || value.trim().length === 0) {
      callback()
    } else if (!req.test(value.trim())) {
      callback('请输入正整数')
    } else if (parseInt(value.trim(), 10) > 1000) {
      callback('不能大于1000')
    } else {
      callback()
    }
  }



  _checkBoxWeek = (rule, value, callback) => {
    if(value && value.length === 0){
      callback('有效日期必选')
    }else{
      callback()
    }
}


  _checkDate = (rule, value, callback) => {
    callback()
  }

  _onChange = () => {
    this.setState({
      refash: true
    })
  }

  _disabledStartDate = (startValue) => {
    const { formData } = this.state
    if (!startValue || !formData.end_times) {
      return startValue && startValue.getTime() < moment().subtract(1, 'minute')
    }
    return startValue.getTime() > formData.end_times.getTime() || startValue.getTime() < moment().subtract(1, 'minute')
  }

  _disabledEndDate = (endValue) => {
    const { formData } = this.state
    if (!endValue || !formData.start_time) {
      return endValue && endValue.getTime() < moment().subtract(1, 'minute')
    }
    return endValue.getTime() < formData.start_time.getTime() || endValue.getTime() < moment().subtract(1, 'minute')
  }

  _disabledStartDateR (current) {
  let dayBegin = moment().startOf('day').valueOf()
  return current && current.getTime() < dayBegin
}

  _disabledEndDate (current) {
  let dayBegin = moment().startOf('day').valueOf()
  return current && current.getTime() < dayBegin
}

  setValue (field, e, text) {
    let v = e
    const target = e && e.target
    let {formData} = this.state
    if (target) {
      if ((target.nodeName + '').toLowerCase() === 'input' && target.type === 'checkbox') {
        v = target.checked
      } else {
        v = e.target.value
      }
    }

    let needClearStatus = []
    formData[field] = v

    if (field === 'unit' && v === 'MINUTE') {
      formData['task_days'] = '30'
      formData[field] = v
      this.refs.validation.forceValidate(['task_days'])
    } else if (field === 'unit') {
      formData[field] = v
      this.refs.validation.forceValidate(['task_days'])
    } else {

    }

    // 随机任务不选年
    if(field === 'task_type'){
     if(v == '1' && formData.cycle === 'YEAR'){
       formData['cycle'] = 'WEEK'
     }

     formData['restart_times']  = '0'
     formData['restart_times_zdy'] = '0'
     formData['restart_interval']  = '0'
     formData['restart_interval_zdy'] = '0'
     formData['end_num'] = 31
     formData['start_num'] = 1
     formData['start_time2'] = moment('2000-01-01 00:00:00').format('HH:mm')
     formData['end_time'] = moment('2000-01-01 23:50:00').format('HH:mm')
     formData['end_times'] = undefined
     formData['start_date'] = moment().format()
     formData['end_date'] = moment().add(1, 'days').format()
     formData['week_days'] = Object.values(WEEK).slice(0,5)
       needClearStatus.push('restart_times')
       needClearStatus.push('restart_interval')
       needClearStatus.push('random_date')
       needClearStatus.push('random_time')
       needClearStatus.push('random_num')
       needClearStatus.push('week_days')
    }

    if (field === 'cycle'){
      if( v === 'MONTH'){
        formData['end_num'] = 31
        formData['start_num'] = 1
      }else if(v === 'DAY'){

      }

      formData['end_num'] = 31
      formData['start_num'] = 1
      formData['start_time2'] = moment('2000-01-01 00:00:00').format('HH:mm')
      formData['end_time'] = moment('2000-01-01 23:50:00').format('HH:mm')
      formData['start_date'] = moment().format()
      formData['end_date'] = moment().add(1, 'days').format()
      formData['week_days'] = Object.values(WEEK).slice(0,5)
      formData['restart_times']  = '0'
      formData['restart_times_zdy'] = '0'
      formData['restart_interval']  = '0'
      formData['restart_interval_zdy'] = '0'
      needClearStatus.push('restart_times')
      needClearStatus.push('restart_interval')
      needClearStatus.push('random_time')
      needClearStatus.push('random_date')
      needClearStatus.push('random_num')
      needClearStatus.push('week_days')
    }

    if (field === 'restart_times_zdy' ){
         if(v === 'ZDY'){
           v = '1'
         }
         if(v == '0'){
             formData['restart_interval']  = '0'
             formData['restart_interval_zdy'] = '0'
             needClearStatus.push('restart_interval')
         }
        formData['restart_times'] = v
    }
    if (field === 'restart_interval_zdy' ){
        if(v === 'ZDY'){
          v = '1'
        }
        formData['restart_interval'] = v
    }

    if(field === 'start_date' || field === 'end_date'){
      if(v == null && field === 'start_date') {
        v = moment().format()
      }
      if(v == null && field === 'end_date') {
        v = moment().add(1, 'days').format()
      }
      formData[field] = v
    }


    if(field === 'start_time2' || field === 'end_time'){
      v = v && moment(v).format('HH:mm')
      if(v == null && field === 'start_time2') {
        v = moment('2000-01-01 00:00:00').format('HH:mm')
      }
      if(v == null && field === 'end_time') {
        v = moment('2000-01-01 23:50:00').format('HH:mm')
      }
      formData[field] = v
    }

    let obj = {}
    if(needClearStatus.length > 0){ // 清空
      needClearStatus.map(
        (item)=>{
          obj[item] = {
            isValidating: false,
            errors: undefined
          }
        }
      )
    }

    this._validate(field, v, obj)
    this.setState({
      formData
    })
  }

  _validate (field, value, newStatus) {   // newStatus 控制隐藏字段的校验褪色
     let error

     if(field === 'restart_times'){
       if(value && /^[1-9]\d*$/.test(value) &&   +value <= 6)  {
             //error = this.t('taskField.tips.restart_times')
       }else if(value == ''){
             error = '该字段不能为空'
       }else{
           error = '重启次数，正整数【1,6】'
       }
     }

     if(field === 'restart_times_zdy'){
       if( this.state.formData.restart_times == 0 ||   this.state.formData.restart_times == -1 ){
         error = undefined
       }else{
         if( this.state.formData.restart_times && /^[1-9]\d*$/.test(this.state.formData.restart_times) &&   +this.state.formData.restart_times <= 6)  {
               //error = this.t('taskField.tips.restart_times')
         }else if(this.state.formData.restart_times == ''){
               error = '该字段不能为空'
         }else{
             error = '重启次数，正整数【1,6】'
         }
       }
      field = 'restart_times'
     }


     if( field === 'restart_interval'){
      //  if( value && +value > 0 && /^[0-9]+(.[0-9]{1,2})?$/.test(value) &&  +value <= 1000  ){
       if( value && +value > 0 && /^[0-9]+(.[5]{1})?$/.test(value) &&  +value <= 24  ){
             // error = this.t('taskField.tips.restart_interval')
       }else if(value == ''){
             error =  '该字段不能为空'
       }else{
             error = "重启间隔时间不大于24小时,最小单位为半小时"
       }
     }

     if(field === 'restart_interval_zdy'){
       if( this.state.formData.restart_interval == 0 ){
         error = undefined
       }else{
         if( this.state.formData.restart_interval && +this.state.formData.restart_interval > 0 && /^[0-9]+(.[5]{1})?$/.test(this.state.formData.restart_interval) &&  +this.state.formData.restart_interval <= 24  ){
               // error = this.t('taskField.tips.restart_interval')
         }else if(this.state.formData.restart_interval == ''){
               error =  '该字段不能为空'
         }else{
               error = "重启间隔时间不大于24小时,最小单位为半小时"
         }
       }
      field = 'restart_interval'
     }




     if(field === 'start_date'){
       if( this.state.formData.end_date ){
            let formEnd  = this.state.formData.end_date
            if(typeof this.state.formData.end_date === 'string'){
              formEnd = new Date(this.state.formData.end_date)
            }
            if(value > formEnd.getTime()  ){
               error = '起始日期应小于截止日期'
               field  = 'random_date'
           }else{
             error = undefined
             field  = 'random_date'
           }
       }
     }
     if(field === 'end_date'){
           if( this.state.formData.start_date ){
                let formStart  = this.state.formData.start_date
                if(typeof this.state.formData.start_date === 'string'){
                  formStart = new Date(this.state.formData.start_date)
                }
                if(moment(value).hour(23).minute(59).second(59).millisecond(999).format('YYYY-MM-DDTHH:mm:ss') < formStart.getTime()  ){
                   error = '起始日期应小于截止日期'
                   field  = 'random_date'
               }else if(this.state.formData.cycle === 'MONTH' &&  moment(formStart).endOf('month').valueOf() < value ){
                   error = `超过周期【月】限制，请在【${moment(formStart).format('MM-DD')}，${moment(moment(formStart).endOf('month')).format('MM-DD')}】选择`
                   field  = 'random_date'
               }else{
                 error = undefined
                 field  = 'random_date'
               }
           }
     }

     if(field === 'cycle'){
       if(this.state.formData.start_num  > 0 &&　this.state.formData.end_num > 0){
              let formStart  = this.state.formData.start_num
              let formEnd  = this.state.formData.end_num
              if( +formEnd < +formStart ){
                 error = '起始日期应小于截止日期'
                 field  = 'random_num'
              }else if(value === 'MONTH') {
                if(   !/^([1-9]|[1-2]\d|3[0-1])$/.test(+formEnd) || !/^([1-9]|[1-2]\d|3[0-1])$/.test(+formStart) ){
                  error = `区间范围【1,31】`
                }else{
                  error = undefined
                }
              }else{
                error = undefined
              }
       }
       field = 'random_num'
     }

     if(field === 'start_time2'){
       if( this.state.formData.end_time ){
            let formEnd2  = this.state.formData.end_time
            if(typeof this.state.formData.end_time === 'string'){
              formEnd2 = new Date(moment().format('YYYY') + ' ' + this.state.formData.end_time)
            }
            if(typeof value === 'string'){
              value = new Date(moment().format('YYYY') + ' ' + value)
            }
            if(value > formEnd2.getTime()  ){
               error = '起始时间段应小于截止时间段'
               field  = 'random_time'
           }else if( formEnd2.getTime()  - value < 30 * 60 * 1000  ){
             error = '下发时间间隔不小于30分钟'
             field  = 'random_time'
           }else{
               error = undefined
               field  = 'random_time'
           }
       }
     }
     if(field === 'end_time'){
           if( this.state.formData.start_time2 ){
                let formStart2  = this.state.formData.start_time2
                if(typeof this.state.formData.start_time2 === 'string'){
                  formStart2 = new Date(moment().format('YYYY') + ' ' + this.state.formData.start_time2)
                }
                if(typeof value === 'string'){
                  value = new Date(moment().format('YYYY') + ' ' + value)
                }
                if(value < formStart2.getTime()  ){
                   error = '起始时间段应小于截止时间段'
                   field  = 'random_time'
               }else if( value - formStart2.getTime() < 30 * 60 * 1000  ){
                 error = '下发时间间隔不小于30分钟'
                 field  = 'random_time'
               }else {
                   error = undefined
                   field  = 'random_time'
               }
           }
     }

     if(field === 'start_num'){
       if( this.state.formData.end_num > 0 ){
            let formEndNum  = this.state.formData.end_num
            if( +value > +formEndNum  ){
               error = '起始时间段应小于截止时间段'
           }else if(this.state.formData.cycle === 'MONTH' ){
             if(    !/^([1-9]|[1-2]\d|3[0-1])$/.test(+value) ||  !/^([1-9]|[1-2]\d|3[0-1])$/.test(+formEndNum)  ){
               error = `区间范围【1,31】`
             }else{
               error = undefined
             }
           }else{
               error = undefined
           }
       }
             field  = 'random_num'
     }

     if(field === 'end_num'){
           if( this.state.formData.start_num  > 0){
                let formStartNum  = this.state.formData.start_num
                if( +value < +formStartNum  ){
                   error = '起始时间段应小于截止时间段'
               }else if(this.state.formData.cycle === 'MONTH'  ){
                 if(  !/^([1-9]|[1-2]\d|3[0-1])$/.test(+value) ||  !/^([1-9]|[1-2]\d|3[0-1])$/.test(+formStartNum) ){
                   error = `区间范围【1,31】`
                 }else{
                   error = undefined
                 }
               }else{
                   error = undefined
               }
           }
             field  = 'random_num'
     }


     if (error) {
       this.setState({
         status: {
           ...this.state.status,
           [field]: {
             isValidating: false,
             errors: [error]
           },
           ...newStatus
         }
       })
     } else {
       this.setState({
         status: {
           ...this.state.status,
           [field]: {
             isValidating: false,
             errors: undefined
           },
           ...newStatus
         }
       })
     }
     return !error
   }

   _handleDefaultSubmit (e) {
    e.preventDefault()
  }

  fiveDisable(start, end , times,h ) {
  const result = [];
  for (let i = start; i < end; i++) {
    let  is  = i / times
    if( is % 1  !== 0 ){
          result.push(i);
    }
    if( i === 55 &&  h === 23){
          result.push(i);
    }
  }
  return result;
}

   _show = () => {
    this.setState({
      visible: true
    })
  }

  _handleCancle = () => {
    this.setState({
      visible: false
    })
  }

  render () {
    const { status, formData } = this.state
    const { t } = this
    const { statusType = [] } = this.props
    let options = []
    let busines = {}
    if (this.props.business && this.props.business.items) {
      options = this.props.business.items
      for (let option of options) {
        if (option.business_id === formData.business_id) {
          busines = option
          this.business = option
          break
        }
      }
    }

    let taskcodeOpt = []
    if (this.props.taskslist && this.props.taskslist.items) {
      taskcodeOpt = this.props.taskslist.items
    }


    let taskTypeOptions = []
    for (let index in TASK_TYPE) {
      taskTypeOptions.push(
        <Radio value={`${index}`} key={index}>
          {TASK_TYPE[index]}</Radio>
      )
    }
    let pushIMOptions = []
    for (let index in TASK_PUSHIM) {
      pushIMOptions.push(
        <Radio value={`${index}`} key={index}>
          {TASK_PUSHIM[index]}</Radio>
      )
    }


    let restartTimesOptions = []
    for (let index in TASK_RESTART_TIMES) {
      restartTimesOptions.push(
         <Option  value={`${index}`} key={index}>
          {TASK_RESTART_TIMES[index]}</Option>
      )
    }
    restartTimesOptions.push(  <Option value='ZDY' key='ZDY' >自定义次数</Option> )

    let restartIntervalOptions = []
    for (let index in TASK_RESTART_INTERVAL) {
      restartIntervalOptions.push(
         <Option  value={`${index}`} key={index}>
          {TASK_RESTART_INTERVAL[index]}</Option>
      )
    }
    restartIntervalOptions.push(  <Option value='ZDY' key='ZDY' >自定义(小时数)</Option> )

    let weekOptions = []
    for (let index in WEEK) {
      weekOptions.push(
        WEEK[index]
      )
    }


    let cycleOptions = []
    if( formData.task_type == '1'){
      cycleOptions.push(<Option value='DAY'>天</Option>)
      cycleOptions.push(<Option value='WEEK'>周</Option>)
      cycleOptions.push(<Option value='MONTH'>月</Option>)
      cycleOptions.push(<Option value='CUSTOM'>自定义每日</Option>)
      cycleOptions.push(<Option value='ONCE'>一次性</Option>)
    }else{
      cycleOptions.push(<Option value='DAY'>天</Option>)
      cycleOptions.push(<Option value='WEEK'>周</Option>)
      cycleOptions.push(<Option value='MONTH'>月</Option>)
      cycleOptions.push(<Option value='YEAR'>年</Option>)
      cycleOptions.push(<Option value='CUSTOM'>自定义每日</Option>)
      cycleOptions.push(<Option value='ONCE'>一次性</Option>)
    }
    console.log(formData,status)

    let rulewayOptions = []
    for (let index in RULE_WAY) {
      rulewayOptions.push(
        <Radio value={`${index}`} key={index}>
          {RULE_WAY[index]}</Radio>
      )
    }

    let statusTypeOptions = []
    if (statusType && statusType.length > 0) {
      statusType.map(
        (item, index) => {
          statusTypeOptions.push(<Option value={item} key={item} > {`${item}`}</Option>)
          })
        }

    let presetTimes = []
    if (this.props.presetTimeTask && this.props.presetTimeTask.items) {
      presetTimes = [...this.props.presetTimeTask.items]
    }


    return <div className='tasks-operation'>
        <div className='panel margin-bottom-1em'>
          <div className='panel-title'>{this.props.clone ? '克隆' : this.props.id ? t('edit') : t('add')}{'任务'}</div>
          <div className='panel-body border-bottom padding0'>
            <Form horizontal onSubmit={this._handleDefaultSubmit}>
              <Validation ref='validation' onValidate={this.handleValidate.bind(this)}>
                <table className='ant-table info-table'>
                  <tbody className='ant-table-tbody'>
                    {
                      this.props.id && !this.props.clone
                      ? <tr>
                          <td>
                            <FormItem
                              label={'任务代码：'}
                              required
                              labelCol={{span: 3}}
                              wrapperCol={{span: 6, offset: 1}}
                              validateStatus={this._renderValidateStyle('task_code')}
                              help={status.task_code.errors ? status.task_code.errors.join(',') : null}>
                              <Validation.Validator rules={[{required: true, message: '请输入任务代码'}]}>
                                <Input name='task_code'
                                  id='task_code'
                                  title={formData.task_code}
                                  disabled
                                  value={formData.task_code}/>
                              </Validation.Validator>
                            </FormItem>
                          </td>
                        </tr>
                      : <tr style={{display: 'none'}}>
                          <td></td>
                        </tr>
                    }
                    <tr>
                      <td>
                        <FormItem
                          label={'任务名称：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 6, offset: 1}}
                          validateStatus={this._renderValidateStyle('task_name')}
                          help={status.task_name.errors ? status.task_name.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请输入任务名称'}, {whitespace: true, message: '请输入任务名称'}, {validator: this._checkName}]}>
                            <Input name='task_name'
                              id='task_name'
                              value={formData.task_name}
                              placeholder = {'请输入任务名称'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'所属任务列表：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 3, offset: 1}}
                          validateStatus={this._renderValidateStyle('list_code')}
                          help={status.list_code.errors ? status.list_code.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请选择所属任务列表'}]}>
                            <Select size='large' placeholder='请选择所属任务列表' style={{width: '100%'}} name='list_code' value={formData.list_code} onChange={this._onChange}>
                              {taskcodeOpt.map((item) => {
                                return <Option value={item.list_code} key={item.list_code}>{item.list_name || item.list_code}</Option>
                              })}
                            </Select>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'任务描述：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 6, offset: 1}}
                          validateStatus={this._renderValidateStyle('desc')}
                          help={status.desc.errors ? status.desc.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请输入任务描述'}, {whitespace: true, message: '请输入任务描述'}, {validator: this._checkDesc}]}>
                            <Input name='desc'
                              type='textarea'
                              style={{height: 100}}
                              id='desc'
                              value={formData.desc}
                              placeholder = {'请输入任务描述'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'任务优先级：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 7, offset: 1}}
                          validateStatus={this._renderValidateStyle('priority')}
                          help={status.priority.errors ? status.priority.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请选择任务优先级'}]}>
                            <RadioGroup name='priority' value={formData.priority !== null && formData.priority !== undefined ? formData.priority + '' : ''} onChange={this._onChange}>
                              <Radio value='1'>高</Radio>
                              <Radio value='2'>中</Radio>
                              <Radio value='3'>低</Radio>
                            </RadioGroup>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'统计方式：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 7, offset: 1}}
                          validateStatus={this._renderValidateStyle('statis_way')}
                          help={status.statis_way.errors ? status.statis_way.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请选择统计方式'}]}>
                            <RadioGroup name='statis_way' value={formData.statis_way !== null && formData.statis_way !== undefined ? formData.statis_way + '' : ''} onChange={this._onChange}>
                              <Radio value='0'>统计进度</Radio>
                              <Radio value='1'>统计值</Radio>
                            </RadioGroup>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          key={formData.statis_way + ''}
                          label={'统计来源：'}
                          required={formData.statis_way + '' === '0'}
                          labelCol={{span: 3}}
                          wrapperCol={{span: 6, offset: 1}}
                          validateStatus={this._renderValidateStyle('statis_source')}
                          help={status.statis_source.errors ? status.statis_source.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: formData.statis_way + '' === '0', message: '请输入统计来源'}, {whitespace: true, message: '请输入统计来源'}, {max: 50, message: '统计来源不能超过50字符'}]}>
                            <Input name='statis_source'
                              id='statis_source'
                              value={formData.statis_source}
                              placeholder = {'请输入统计来源'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          required
                          label={'是否红点统计：'}
                          labelCol={{span: 3}}
                          wrapperCol={{span: 7, offset: 1}}
                          validateStatus={this._renderValidateStyle('red_remind')}
                          help={status.red_remind.errors ? status.red_remind.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请选择是否红点统计'}]}>
                            <RadioGroup name='red_remind' value={formData.red_remind !== null && formData.red_remind !== undefined ? formData.red_remind + '' : ''} onChange={this._onChange}>
                              <Radio value='true'>是</Radio>
                              <Radio value='false'>否</Radio>
                            </RadioGroup>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          required
                          label={'任务链类型：'}
                          labelCol={{span: 3}}
                          wrapperCol={{span: 7, offset: 1}}
                          validateStatus={this._renderValidateStyle('task_linked_type')}
                          help={status.task_linked_type.errors ? status.task_linked_type.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请选择任务链类型'}]}>
                            <RadioGroup name='task_linked_type' value={formData.task_linked_type} onChange={this._onChange}>
                              <Radio value='disOrder'>无序</Radio>
                              <Radio value='order'>有序</Radio>
                            </RadioGroup>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                    <FormItem label={`任务类型：`}
                      required
                      labelCol={{span: 3}}
                      wrapperCol={{span: 7, offset: 1}}
                      validateStatus={this._renderValidateStyle('task_type')}
                      hasFeedback ={false}
                      help={status.task_type.errors ? status.task_type.errors.join(',') : null}>
                      {/* <Validation.Validator rules={[{required: true, message: '请选择任务类型'}]}> */}
                          <RadioGroup value={   (+formData.task_type) + ''} id='task_type' name='task_type'  onChange={this.setValue.bind(this, 'task_type')} >
                            {taskTypeOptions}
                          </RadioGroup>
                      {/* </Validation.Validator> */}
                      </FormItem>
                    </td>
                  </tr>

                    <tr>
                      <td>
                        <FormItem
                          label={'任务周期：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 3, offset: 1}}
                          validateStatus={this._renderValidateStyle('cycle')}
                          help={status.cycle.errors ? status.cycle.errors.join(',') : null}>

                          {/* <Validation.Validator rules={[{required: true, message: '请选择任务周期'}]}> */}
                            <Select size='large' placeholder='请选择任务周期' style={{width: '100%'}} name='cycle' value={formData.cycle} onChange={this.setValue.bind(this, 'cycle')} >
                              {cycleOptions}
                            </Select>
                          {/* </Validation.Validator> */}
                        </FormItem>
                      </td>
                    </tr>
                    {
                      formData.task_type + '' === '1' && formData.cycle === 'ONCE'
                      ? <tr>
                          <td>
                            <FormItem
                                label={'任务开始日期：'}
                                labelCol={{span: 3}}
                                wrapperCol={{span: 20, offset: 1}}
                                validateStatus={this._renderValidateStyle('start_time')}
                                help={status.start_time.errors ? status.start_time.errors.join(',') : null}>
                                <Row>
                                  <Col span='24'>
                                    <Validation.Validator rules={[{
                                      validator: this._checkDate
                                    }]}>
                                      <DatePicker disabledDate={this._disabledStartDate}
                                        name='start_time'
                                        showTime={ true }
                                        value={formData.start_time}
                                        format='yyyy-MM-dd HH:mm:ss'
                                        placeholder={'请选择任务开始日期'}/>
                                    </Validation.Validator>
                                    <div className='warn'>{'提示：设置任务开始日期后，配置推送不允许设置该任务间隔天数'}</div>
                                  </Col>
                                </Row>
                              </FormItem>
                            </td>
                        </tr>
                      : <tr style={{display: 'none'}}>
                          <td></td>
                        </tr>
                    }
                    {
                      formData.task_type + '' !== '1'
                      ? <tr>
                          <td>
                            <FormItem
                                label={'任务开始日期：'}
                                labelCol={{span: 3}}
                                wrapperCol={{span: 20, offset: 1}}
                                validateStatus={this._renderValidateStyle('start_time')}
                                help={status.start_time.errors ? status.start_time.errors.join(',') : null}>
                                <Row>
                                  <Col span='24'>
                                    <Validation.Validator rules={[{
                                      validator: this._checkDate
                                    }]}>
                                      <DatePicker disabledDate={this._disabledStartDate}
                                        name='start_time'
                                        showTime={ true }
                                        value={formData.start_time}
                                        format='yyyy-MM-dd HH:mm:ss'
                                        placeholder={'请选择任务开始日期'}/>
                                    </Validation.Validator>
                                    <div className='warn'>{'提示：设置任务开始日期后，配置推送不允许设置该任务间隔天数'}</div>
                                  </Col>
                                </Row>
                              </FormItem>
                            </td>
                        </tr>
                      : <tr style={{display: 'none'}}>
                          <td></td>
                        </tr>
                    }
                    {
                      formData.task_type + '' !== '1'
                      ? <tr>
                          <td>
                            <FormItem
                                label={'任务结束时间：'}
                                labelCol={{span: 3}}
                                wrapperCol={{span: 20, offset: 1}}
                                validateStatus={this._renderValidateStyle('end_times')}
                                help={status.end_times.errors ? status.end_times.errors.join(',') : null}>
                                <Row>
                                  <Col span='24'>
                                    <Validation.Validator rules={[{
                                      validator: this._checkDate
                                    }]}>
                                      <DatePicker disabledDate={this._disabledEndDate}
                                        name='end_times'
                                        showTime={ true }
                                        value={formData.end_times}
                                        format='yyyy-MM-dd HH:mm:ss'
                                        placeholder={'请选择任务结束日期'}/>
                                    </Validation.Validator>
                                  </Col>
                                </Row>
                              </FormItem>
                            </td>
                        </tr>
                      : <tr style={{display: 'none'}}>
                          <td></td>
                        </tr>
                    }
                    {
                      formData.task_type + '' !== '1'
                      ? <tr>
                          <td>
                          <FormItem
                          label={'时间配置：'}
                          labelCol={{span: 3}}
                          wrapperCol={{span: 3, offset: 1}}
                          validateStatus={this._renderValidateStyle('date_config_id')}
                          help={status.date_config_id.errors ? status.date_config_id.errors.join(',') : null}>

                          {/* <Validation.Validator rules={[{required: true, message: '请选择任务周期'}]}> */}
                            <Select size='large' placeholder='请选择时间配置' style={{width: '100%'}} name='date_config_id' value={formData.date_config_id} onChange={this.setValue.bind(this, 'date_config_id')} notFoundContent='暂无'>
                              {
                                presetTimes.map(item => {
                                  return <Option value={item.id} key={item.id} >{item.title}</Option>
                                })
                              }
                            </Select>
                          {/* </Validation.Validator> */}
                        </FormItem>
                            </td>
                        </tr>
                      : <tr style={{display: 'none'}}>
                          <td></td>
                        </tr>
                    }
                    {
                      formData.cycle === 'ONCE' || formData.task_type == '1'
                      ? <tr>
                          <td>
                           {
                              formData.unit === 'NONE'
                              ? <FormItem
                                  label={'完成时限：'}
                                  required
                                  labelCol={{span: 3}}
                                  wrapperCol={{span: 3, offset: 1}}>
                                  <Select style={{ width: 65 }} id='unit' name='unit' value={formData.unit || 'DAY'} onChange={this.setValue.bind(this, 'unit')}>
                                    <Option value='DAY' key='DAY' >天</Option>
                                    <Option value='HOUR' key='HOUR' >小时</Option>
                                    <Option value='MINUTE' key='MINUTE' >分钟</Option>
                                    {formData.task_type != 1 ? <Option value='NONE' key='NONE' >不限</Option> : null }
                                  </Select>
                                </FormItem>
                              : <FormItem
                                  label={'完成时限：'}
                                  required
                                  labelCol={{span: 3}}
                                  wrapperCol={{span: 3, offset: 1}}
                                  validateStatus={this._renderValidateStyle('task_days')}
                                  help={status.task_days.errors ? status.task_days.errors.join(',') : null}>
                                    <InputGroup>
                                      <Validation.Validator rules={[{required: true, message: '请输入完成时限'}, {whitespace: true, message: '请输入完成时限'}, {validator: this._checksTaskdays}]}>
                                        <Input id='task_days'
                                        name='task_days'
                                        placeholder={'请输入完成时限'}
                                        value={formData.task_days === null ? '1' : formData.task_days + ''}
                                        onChange={this.setValue.bind(this, 'task_days')}/>
                                      </Validation.Validator>
                                      <div className='ant-input-group-wrap'>
                                        <Select style={{ width: 65 }} id='unit' name='unit' value={formData.unit || 'DAY'} onChange={this.setValue.bind(this, 'unit')}>
                                          <Option value='DAY' key='DAY' >天</Option>
                                          <Option value='HOUR' key='HOUR' >小时</Option>
                                          <Option value='MINUTE' key='MINUTE' >分钟</Option>
                                            {formData.task_type != 1 ? <Option value='NONE' key='NONE' >不限</Option> : null }
                                        </Select>
                                      </div>
                                    </InputGroup>
                                </FormItem>
                            }
                          </td>
                        </tr>
                      : <tr style={{display: 'none'}}>
                          <td></td>
                        </tr>
                    }


                            { formData.task_type == '1' ? <tr> <td> <Tag color='blue'>随机任务配置</Tag>
                              <FormItem label={`${t('taskIsPushIM')}：`}
                                required
                                labelCol={{span: 3}}
                                wrapperCol={{span: 3, offset: 1}}
                                validateStatus={this._renderValidateStyle('push')}
                                hasFeedback
                                 help={status.push.errors ? status.push.errors.join(',') : null} >
                                 <Validation.Validator rules={[{required: true, message: '请选择是否推送IM消息'}]}>
                                     <RadioGroup value={ formData.push + ''} id='push' name='push'  onChange={this._onChange}>
                                       {pushIMOptions}
                                     </RadioGroup>
                                 </Validation.Validator>
                              </FormItem>



                              {formData.cycle === 'WEEK' || formData.cycle === 'CUSTOM' ?
                              <FormItem label={`${t('taskWorksDay')}：`}
                                required
                                labelCol={{span: 3}}
                                wrapperCol={{span: 10, offset: 1}}
                                validateStatus={ this._renderValidateStyle('week_days') }
                                hasFeedback={false}
                                help={status.week_days.errors  ? status.week_days.errors.join(',') : null}>
                                       <Validator rules={[
                                         {
                                           validator:this._checkBoxWeek
                                         }
                                                 ]}>
                                 <CheckboxGroup id='week_days' name='week_days' options={weekOptions} onChange={this.setValue.bind(this, 'week_days')} value={formData.week_days} />
                                       </Validator>
                               </FormItem> :null}


                               {formData.cycle ==='MONTH' ?
                               <FormItem label={`${t('taskRandomDay')}：`}
                                 required
                                 validateStatus={this._renderValidateStyle('random_num')}
                                 hasFeedback
                                 labelCol={{span: 3}}
                                 wrapperCol={{span: 6, offset: 1}}
                                 help={status.random_num.errors ? status.random_num.errors.join(',') : null} >
                                <div style={{ display: "flex"}}>
                                  <Input id='start_num' name='start_num' style={{ width: 50 }}  value={formData.start_num === null ? '1' : formData.start_num + ''}
                                    onChange={this.setValue.bind(this, 'start_num')} />
                                   <span style={{ margin: '0 5px',lineHeight:'32px'}}> 至 </span>
                                   <Input id='end_num' name='end_num' style={{ width: 50 }}  value={formData.end_num === null ? '31' : formData.end_num + ''}
                                     onChange={this.setValue.bind(this, 'end_num')} />
                                </div>
                               </FormItem> :null
                               }


                                 {formData.cycle ==='ONCE' ? <FormItem label={`${t('taskRandomDay')}：`} required validateStatus={this._renderValidateStyle('random_date')} hasFeedback={false} help={status.random_date.errors
                                  ? status.random_date.errors.join(',') : null}   labelCol={{span: 3}} wrapperCol={{span: 6, offset: 1}}>
                                  <div style={{ display: "flex"}}>
                                    <DatePicker  id='start_date' name='start_date'  format={'yyyy-MM-dd'}
                                          disabledDate={this._disabledStartDateR} onChange={this.setValue.bind(this, 'start_date')} value={formData.start_date}/>
                                     <span style={{ margin: '0 5px',lineHeight:'32px'}}> 至 </span>
                                    <DatePicker  id='end_date' name='end_date'  format={'yyyy-MM-dd'}
                                          disabledDate={this._disabledEndDate} onChange={this.setValue.bind(this, 'end_date')} value={formData.end_date}/>
                                  </div>
                                 </FormItem> :null
                                 }


                                 <FormItem label={`${t('taskRandomTime')}：`} required validateStatus={this._renderValidateStyle('random_time')} hasFeedback={false} help={status.random_time.errors
                                   ? status.random_time.errors.join(',') : null}   labelCol={{span: 3}} wrapperCol={{span: 6, offset: 1}}>
                                   <div style={{ display: "flex"}}>
                                     <TimePicker   id='start_time2' name='start_time2'  format="HH:mm"  hideDisabledOptions  disabledMinutes={ (h) => {return this.fiveDisable(0,60,5,h) } }
                                       onChange={this.setValue.bind(this, 'start_time2')} value={formData.start_time2}/>
                                      <span style={{ margin: '0 5px',lineHeight:'32px'}}> 至 </span>
                                     <TimePicker   id='end_time' name='end_time'  format="HH:mm"  hideDisabledOptions  disabledMinutes={ (h)=>{return this.fiveDisable(0,60,5,h)} }
                                       onChange={this.setValue.bind(this, 'end_time')} value={formData.end_time}/>
                                   </div>
                                 </FormItem>


                                 {  formData.restart_times_zdy === 'ZDY' ?
                                  <FormItem label={`${t('taskRestartTimes')}：`}
                                   required
                                   labelCol={{span: 3}}
                                   wrapperCol={{span: 3, offset: 1}}
                                   validateStatus={this._renderValidateStyle('restart_times')}
                                   hasFeedback={false}
                                   help={status.restart_times.errors ? status.restart_times.errors.join(',') : null} >
                                        <InputGroup>
                                         <Input id='restart_times' name='restart_times' style={{ width: 65 }} placeholder={'输入重启次数'} value={formData.restart_times === null ? '1' : formData.restart_times + ''}
                                           onChange={this.setValue.bind(this, 'restart_times')}
                                         />
                                         <div className="ant-input-group-wrap selectUnit">
                                           <Select style={{ width: 145 }} id='restart_times_zdy' name='restart_times_zdy'
                                             value={ +formData.restart_times != '-1' && +formData.restart_times != '0' ? 'ZDY': (+formData.restart_times) + ''} onChange={this.setValue.bind(this, 'restart_times_zdy')}>
                                             {restartTimesOptions}
                                           </Select>
                                          </div>
                                          </InputGroup>
                                     </FormItem> : <FormItem label={`${t('taskRestartTimes')}：`}
                                       required
                                       labelCol={{span: 3}}
                                       wrapperCol={{span: 3, offset: 1}}
                                       validateStatus={this._renderValidateStyle('restart_times')}
                                       hasFeedback={false}
                                       help={status.restart_times.errors ? status.restart_times.errors.join(',') : null} >
                                               <div className="ant-input-group-wrap selectUnit">
                                                 <Select style={{ width: 145 }} id='restart_times_zdy' name='restart_times_zdy'
                                                   value={ +formData.restart_times != '-1' && +formData.restart_times != '0' ? 'ZDY':  (+formData.restart_times) + ''} onChange={this.setValue.bind(this, 'restart_times_zdy')}>
                                                   {restartTimesOptions}
                                                 </Select>
                                                </div>
                                     </FormItem>
                                 }


                                 { formData.restart_times != 0 ? formData.restart_interval_zdy === 'ZDY' ?
                                 <FormItem label={`${t('taskRestartInterval')}：`}
                                   required
                                   validateStatus={this._renderValidateStyle('restart_interval')}
                                   hasFeedback={false}
                                   labelCol={{span: 3}}
                                   wrapperCol={{span: 3, offset: 1}}
                                   help={status.restart_interval.errors ? status.restart_interval.errors.join(',')  : null}>
                                      <InputGroup>
                                       <Input id='restart_interval' name='restart_interval' style={{ width: 65 }} placeholder={'输入重启间隔时间'} value={formData.restart_interval === null ? '1' : formData.restart_interval + ''}
                                         onChange={this.setValue.bind(this, 'restart_interval')}
                                       />
                                       <div className="ant-input-group-wrap selectUnit">
                                         <Select style={{ width: 145 }} id='restart_interval_zdy' name='restart_interval_zdy' value={formData.restart_interval != '0' ? 'ZDY': formData.restart_interval  + ''} onChange={this.setValue.bind(this, 'restart_interval_zdy')}>
                                           {restartIntervalOptions}
                                         </Select>
                                        </div>
                                        </InputGroup>
                                   </FormItem>  :  <FormItem label={`${t('taskRestartInterval')}：`}
                                      required
                                      validateStatus={this._renderValidateStyle('restart_interval')}
                                      hasFeedback={false}
                                      labelCol={{span: 3}}
                                      wrapperCol={{span: 3, offset: 1}}
                                      help={status.restart_interval.errors ? status.restart_interval.errors.join(',') : null}  >
                                       <div className="ant-input-group-wrap selectUnit">
                                         <Select style={{ width: 145 }} id='restart_interval_zdy' name='restart_interval_zdy' value={ formData.restart_interval != '0' ? 'ZDY': formData.restart_interval  + ''} onChange={this.setValue.bind(this, 'restart_interval_zdy')}>
                                           {restartIntervalOptions}
                                         </Select>
                                        </div>
                                   </FormItem> : null
                                 }

                                   </td>
                               </tr> : null }

                    <tr>
                      <td>
                        <FormItem
                          label={'进度上限：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 3, offset: 1}}
                          validateStatus={this._renderValidateStyle('max_schedule')}
                          help={status.max_schedule.errors ? status.max_schedule.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请输入进度上限'}, {whitespace: true, message: '请输入进度上限'}, {validator: this._checksChedule}]}>
                            <Input name='max_schedule'
                              id='max_schedule'
                              value={formData.max_schedule === null || formData.max_schedule === undefined ? '1' : formData.max_schedule + ''}
                              placeholder = {'请输入进度上限'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'完成条件描述：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 6, offset: 1}}
                          validateStatus={this._renderValidateStyle('requirement')}
                          help={status.requirement.errors ? status.requirement.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请输入完成条件描述'}, {whitespace: true, message: '请输入完成条件描述'}, {validator: this._checkDesc}]}>
                            <Input name='requirement'
                              type='textarea'
                              style={{height: 100}}
                              id='requirement'
                              value={formData.requirement}
                              placeholder = {'请输入完成条件描述'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'任务标签：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 6, offset: 1}}
                          validateStatus={this._renderValidateStyle('task_tag')}
                          help={status.task_tag.errors ? status.task_tag.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请输入任务标签'}, {whitespace: true, message: '请输入任务标签'}, {validator: this._checkName}]}>
                            <Input name='task_tag'
                              id='task_tag'
                              value={formData.task_tag}
                              placeholder = {'请输入任务标签'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                          <FormItem label={`状态计算方式：`}
                          required validateStatus={this._renderValidateStyle('rule_way')}
                          hasFeedback={false} help={status.rule_way.errors ? status.rule_way.errors.join(',') : null}
                          labelCol={{span: 3}}
                          wrapperCol={{span: 6, offset: 1}}>
                            <Validation.Validator rules={[{ required: true, message: '请选择状态计算方式' } ]}>
                              <RadioGroup value={formData.rule_way === null ? '1' : formData.rule_way + '' } id='rule_way' name='rule_way'  onChange={this.setValue.bind(this, 'rule_way')}>
                                {rulewayOptions}
                              </RadioGroup>
                            </Validation.Validator>
                          </FormItem>
                          </td>
                        </tr>
                        <tr>
                          <td>
                          <FormItem label={`状态类别：`}
                          required={false} validateStatus={this._renderValidateStyle('status_type')}
                          hasFeedback={false}
                          help={status.status_type.errors ? status.status_type.errors.join(',') : null}
                          labelCol={{span: 3}}
                          wrapperCol={{span: 3, offset: 1}}>
                            <Validation.Validator rules={[{ required: false, message: '请选择状态类别' } ]}>
                            <Select  placeholder={'状态类别'}  size='large' style={{width: '100%'}}  id='status_type' name='status_type' value={formData.status_type} onChange={this.setValue.bind(this, 'status_type')}>
                              {statusTypeOptions}
                            </Select>
                            </Validation.Validator>
                          </FormItem>
                          </td>
                        </tr>
                    { formData.task_type != '1' ? <tr>
                      <td>
                        <FormItem
                          label={'是否允许延期：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 7, offset: 1}}
                          validateStatus={this._renderValidateStyle('auto_delay')}
                          help={status.auto_delay.errors ? status.auto_delay.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请选择是否允许延期'}]}>
                            <RadioGroup name='auto_delay' value={formData.auto_delay !== null && formData.auto_delay !== undefined ? formData.auto_delay + '' : ''} onChange={this._onChange}>
                              <Radio value='1'>是</Radio>
                              <Radio value='0'>否</Radio>
                            </RadioGroup>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>    : <tr style={{display: 'none'}}>
                            <td></td>
                          </tr>
                      }
                    {
                      formData.auto_delay + '' === '1' &&   formData.task_type != '1'
                      ? <tr>
                          <td>
                            <FormItem
                              label={'最大延期天数：'}
                              required
                              labelCol={{span: 3}}
                              wrapperCol={{span: 3, offset: 1}}
                              validateStatus={this._renderValidateStyle('delay_days')}
                              help={status.delay_days.errors ? status.delay_days.errors.join(',') : null}>
                              <Validation.Validator rules={[{required: true, message: '请输入最大延期天数'}, {whitespace: true, message: '请输入最大延期天数'}, {validator: this._checkDelayDays}]}>
                                <Input name='delay_days'
                                  id='delay_days'
                                  value={formData.delay_days ? formData.delay_days + '' : ''}
                                  placeholder = {'请输入最大延期天数'}/>
                              </Validation.Validator>
                            </FormItem>
                          </td>
                        </tr>
                      : <tr style={{display: 'none'}}>
                          <td></td>
                        </tr>
                    }
                    <tr>
                      <td>
                        <FormItem
                          label={'接入业务：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 3, offset: 1}}
                          validateStatus={this._renderValidateStyle('business_id')}
                          help={status.business_id.errors ? status.business_id.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请选择接入业务'}]}>
                            <Select size='large' placeholder='请选择接入业务' style={{width: '100%'}} name='business_id' value={formData.business_id} onChange={this._onChange}>
                              {options.map((item) => {
                                return <Option value={item.business_id} key={item.business_id}>{item.business_name || item.business_id}</Option>
                              })}
                            </Select>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    {
                      formData.business_id
                      ? <tr>
                          <td>
                            <FormItem
                              key={formData.business_id}
                              label={'业务参数：'}
                              required={busines.is_param}
                              labelCol={{span: 3}}
                              wrapperCol={{span: 20, offset: 1}}
                              validateStatus={this._renderValidateStyle('param')}
                              help={status.param.errors ? status.param.errors.join(',') : null}>
                                <Row>
                                  <Col span='6'>
                                    <Validation.Validator rules={[{required: busines.is_param, message: busines.param_desc}]}>
                                        <Input name='param'
                                          id='param'
                                          value={formData.param}
                                          placeholder = {busines.param_desc}/>
                                    </Validation.Validator>
                                  </Col>
                                  {
                                    busines.business_url
                                    ? <Col>
                                        <Button
                                          type='primary'
                                          style={{marginLeft: '20px'}}
                                          onClick={this._show}>
                                          {'选择'}
                                        </Button>
                                        <Button
                                          type='primary'
                                          style={{marginLeft: '20px'}}
                                          onClick={this._chearnElearning}>
                                          {'清空'}
                                        </Button>
                                      </Col>
                                    : <Col>
                                        <Button
                                          type='primary'
                                          style={{marginLeft: '20px'}}
                                          onClick={this._chearnElearning}>
                                          {'清空'}
                                        </Button>
                                      </Col>
                                  }
                                </Row>
                            </FormItem>
                          </td>
                        </tr>
                      : <tr style={{display: 'none'}}>
                          <td></td>
                        </tr>
                    }
                    {
                      formData.business_id
                      ? <tr>
                          <td>
                            <FormItem
                              label={'接入状态：'}
                              labelCol={{span: 3}}
                              wrapperCol={{span: 6, offset: 1}}
                              validateStatus={this._renderValidateStyle('tenant_status')}
                              help={status.tenant_status.errors ? status.tenant_status.errors.join(',') : null}>
                              <Validation.Validator rules={[{required: false, message: ''}]}>
                                <RadioGroup name='tenant_status' value={formData.tenant_status !== null && formData.tenant_status !== undefined ? formData.tenant_status + '' : ''}>
                                  <Radio value='true'>是</Radio>
                                  <Radio value='false'>否</Radio>
                                </RadioGroup>
                              </Validation.Validator>
                            </FormItem>
                          </td>
                        </tr>
                      : <tr style={{display: 'none'}}>
                          <td></td>
                        </tr>
                    }
                    <tr>
                      <td>
                        <FormItem
                          label={'客户端跳转地址：'}
                          labelCol={{span: 3}}
                          wrapperCol={{span: 10, offset: 1}}
                          validateStatus={this._renderValidateStyle('link')}
                          help={status.link.errors ? status.link.errors.join(',') : null}>
                          <Validation.Validator rules={[{validator: this._checkLink}]}>
                            <Input name='link'
                              id='link'
                              value={formData.link}
                              placeholder = {'请输入客户端跳转地址'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'PC端跳转地址：'}
                          labelCol={{span: 3}}
                          wrapperCol={{span: 10, offset: 1}}
                          validateStatus={this._renderValidateStyle('web_link')}
                          help={status.web_link.errors ? status.web_link.errors.join(',') : null}>
                          <Validation.Validator rules={[{validator: this._checkLink}]}>
                            <Input name='web_link'
                              id='web_link'
                              value={formData.web_link}
                              placeholder = {'请输入PC端跳转地址'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </Validation>
            </Form>
          </div>
        </div>
        <div className='col-24 text-center margin-bottom-1em'>
          <Button
            type='primary'
            size='large'
            style={{marginRight: '20px'}}
            onClick={this._handleSubmit.bind(this, false)}>
            {'保存'}
          </Button>
          <Button
            type='primary'
            size='large'
            style={{marginRight: '20px'}}
            onClick={this._handleSubmit.bind(this, true)}>
            {'保存并启用'}
          </Button>
          {
            this.props.id && !this.props.clone
            ? <Button
              type='primary'
              size='large'
              style={{marginRight: '20px'}}
              onClick={this._handleComp.bind(this, true)}>
              {'修改比对'}
            </Button>
            : ""
          }
          {
            this.props.id && !this.props.clone
            ? <Button
              type='primary'
              size='large'
              style={{marginRight: '20px'}}
              onClick={this._handleShowLogs}>
              {'查看修改日志'}
            </Button>
            : ""
          }
          <Button onClick={this._handleBack} type='ghost' size='large'>{'返回'}</Button>
        </div>
        <Confirm visible={this.state.visible}
          title={'请选择'}
          width='66%'
          buttons='xx'
          onCancel={this._handleCancle}>
          <div style={{
            textAlign: 'center'
          }}>
            <iframe src={eLeaning.getAuthURL(busines.business_url || '')}
            width='100%' height='500px' name='eLeaning'
            style={{border: 0}}/>
          </div>
        </Confirm>
        <Confirm visible={this.state.visibleComfire}
          title={'提示'}
          width='400px'
          onOk={this._handleWarn}
          onCancel={this._handleWarnCancle}>
          <div style={{
            textAlign: 'center'
          }}>
            {'是否将选中项名称填入任务名称输入框？'}
          </div>
        </Confirm>
      </div>
  }

  _handleComfirm = () => {
    // 通知 e-leaning，我需要获取选中课程/培训
    eLeaning.getItem()
    this.state.visible = false
  }

  _handleWarn = () => {
    this.state.formData.task_name = this.state.elearnName
    this.setState({
      formData: this.state.formData
    })
    this._hide()
  }

  _handleWarnCancle = () => {
    this._hide()
  }

  _hide = () => {
    this.setState({
      visible: false,
      visibleComfire: false
    })
  }
}
