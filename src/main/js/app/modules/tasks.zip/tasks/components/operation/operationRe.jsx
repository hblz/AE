import React, { PropTypes } from 'react'
import i18n from 'i18n'

import { Form, Input, Validation, Button, Radio, Select, message, Row, Col } from 'antd'
import { mixin } from 'core-decorators'
import ConfigLogs from '@sdp.nd/social/libs/jsonDiff'
import UlForm from './ulForm'
import utils from 'utils'

const configLogs = new ConfigLogs()
const FormItem = Form.Item
const RadioGroup = Radio.Group
const cx = (classNames) => {
  if (typeof classNames === 'object') {
    return Object.keys(classNames).filter(function (className) {
      return classNames[className]
    }).join(' ')
  } else {
    return Array.prototype.join.call(arguments, ' ')
  }
}
const tips = ['任务完成自动发放的奖励', '任务完成不自动发放，需要组件发放的奖励']
const keys = {
  reward_code: '奖励代码',
  reward_name: '奖励名称',
  cycle: '发放周期',
  limit: '发放次数限制(次)',
  auto_gained: '自动发放',
  fixed: '固定奖励',
  validate_days: '奖励有效期(天)'
}
@mixin(Validation.FieldMixin)
export default class extends React.Component {
  static propTypes = {
    id: PropTypes.string,
    taskId: PropTypes.string,
    addRewards: PropTypes.func,
    putRewards: PropTypes.func,
    datas: PropTypes.object,
    history: PropTypes.object
  }

  static defaultProps = {
  }

  state = {
    datas: {},
    status: {
      reward_code: {},
      reward_name: {},
      cycle: {},
      limit: {},
      auto_gained: {},
      fixed: {},
      reward_purpose: {},
      validate_days: {}
    },
    formData: {
      reward_code: undefined,
      reward_name: undefined,
      cycle: 'DAY',
      limit: '1',
      auto_gained: 'false',
      fixed: 'false',
      validate_days: '30',
      reward_items: [],
      reward_purpose: undefined,
      bonus: []
    }
  }

  t = i18n.getFixedT(null, 'tasks')

  componentDidMount () {
  }

  /**
   * 表单验证
   */
  _renderValidateStyle = (item) => {
    const status = this.state.status

    return cx({
      'error': status[item].errors,
      'validating': status[item].isValidating,
      'tip': ''
    })
  }

  setFormdatas (data) {
    const formData = this.state.formData
    Object.keys(data).map((key) => {
      formData[key] = data[key]
    })
    this._setCompDatas(data)
    // this.setState({
    //   formData: formData
    // })
  }

  _handleSubmit = (flag) => {
    const { t } = this
    if (!this.state.formData.reward_name) {
      message.error('请输入奖励名称')
    }
    const validation = this.refs.validation
    validation.validate((valid) => {
      if (!valid) {
        return
      } else {
        let formData = this.state.formData
        formData.reward_items = []
        formData.bonus = []
        formData.task_code = this.props.taskId
        let rewards = this.props.datas.rewards.items
        let bonus = this.props.datas.bonus.items
        let req = /^\+?[0-9]*$/
        let flag = false
        for (let i = 0; i < rewards.length; i++) {
          let form = this.refs[`ref${i}`].getStatus()
          if (form.isCheck) {
            // if (!form.name.trim()) {
            //   message.error(`选中的奖励明细值不能为空`)
            //   flag = true
            //   break
            // } else
            if (!req.test(form.name.trim())) {
              message.error(`奖励明细只能为非负整数`)
              flag = true
              break
            } else if (parseInt(form.name.trim(), 10) > 99999) {
              message.error(`奖励明细不能大于99999`)
              flag = true
              break
            }
            formData.reward_items.push({
              item_code: rewards[i].item_code,
              num: form.name
            })
          }
        }
        if (!flag) {
          if (formData.reward_items.length === 0) {
            message.error('奖励明细至少一条')
            return
          }
          for (let j = 0; j < bonus.length; j++) {
            let reward_items = []
            for (let i = 0; i < rewards.length; i++) {
              let form = this.refs[`ref${i}`].getStatus()
              if (form.isCheck) {
                // if (!form[`name${j}`].trim()) {
                //   message.error(`选中的奖励明细值不能为空`)
                //   flag = true
                //   break
                // } else
                if (!req.test(form[`name${j}`].trim())) {
                  message.error(`奖励明细只能为非负整数`)
                  flag = true
                  break
                } else if (parseInt(form[`name${j}`].trim(), 10) > 99999) {
                  message.error(`奖励明细不能大于99999`)
                  flag = true
                  break
                }
                if (form[`name${j}`].trim() && form[`name${j}`].trim() !== '0') {
                  reward_items.push({
                    item_code: rewards[i].item_code,
                    num: form[`name${j}`]
                  })
                }
              }
            }
            formData.bonus.push({
              bonus_code: bonus[j].item_code,
              reward_items: reward_items
            })
          }
        }
        if (flag) {
          return
        }

        let options = {
          data: formData,
          success: {
            text: '',
            handler: (data) => {
              const config_app_id = '养成管理后台.任务配置.任务管理.奖励列表.修改奖励'
              const config_id = this.state.formData.reward_code || data.reward_code
              const content = this._handleComp(false)
              configLogs.saveLog(utils.CONFIG_LOGS, config_app_id, config_id, content, utils.auth.getAuth().user_id, this._handleBack)
            }
          }
        }
        if (this.props.id) {
          options.uri = this.props.id
          this.props.putRewards(options)
        } else {
          this.props.addRewards(options)
        }
      }
    })
  }

  _handleBack = () => {
    this.props.history.pushState(null, `tasks/rewards/${this.props.taskId}`)
  }

  _checkName = (rule, value, callback) => {
    if (!value || value.length === 0) {
      callback()
    } else if (value.trim().length > 50) {
      callback('字符长度不能超过50')
    } else {
      callback()
    }
  }

  _checksChedule = (rule, value, callback) => {
    let req = /^\+?[0-9]*$/
    if (!value || value.trim().length === 0) {
      callback()
    } else if (!req.test(value.trim())) {
      callback('请输入非负整数')
    } else if (parseInt(value.trim(), 10) > 3650) {
      callback('不能大于3650')
    } else {
      callback()
    }
  }

  _checkDelayDays = (rule, value, callback) => {
    let req = /^\+?[1-9][0-9]*$/
    if (!value || value.trim().length === 0) {
      callback()
    } else if (!req.test(value.trim())) {
      callback('请输入正整数')
    } else if (parseInt(value.trim(), 10) > 10) {
      callback('不能大于10')
    } else {
      callback()
    }
  }

  render () {
    const { status, formData } = this.state
    const { t } = this

    let bonus = []
    let rewards = []
    if (this.props.datas.bonus && this.props.datas.bonus.items && this.props.datas.bonus.items.length > 0) {
      bonus = this.props.datas.bonus.items.concat()
    }
    if (this.props.datas.rewards && this.props.datas.rewards.items && this.props.datas.rewards.items.length > 0) {
      rewards = this.props.datas.rewards.items.concat()
    }

    if ((this.props.id && formData.reward_items.length === 0) || bonus.length === 0 || rewards.length === 0) {
      return null
    }

    return <div className='tasks-operation reward-operation'>
        <div className='panel margin-bottom-1em'>
          <div className='panel-title'>{this.props.id ? t('edit') : t('add')}{'奖励'}</div>
          <div className='panel-body border-bottom padding0'>
            <Form horizontal onSubmit={this._preHandleSubmit}>
              <Validation ref='validation' onValidate={this.handleValidate.bind(this)}>
                <table className='ant-table info-table'>
                  <tbody className='ant-table-tbody'>
                    <tr>
                      <td>
                        <FormItem
                          label={'奖励名称：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 6, offset: 1}}
                          validateStatus={this._renderValidateStyle('reward_name')}
                          help={status.reward_name.errors ? status.reward_name.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请输入奖励名称'}, {whitespace: true, message: '请输入奖励名称'}, {validator: this._checkName}]}>
                            <Input name='reward_name'
                              id='reward_name'
                              value={formData.reward_name}
                              placeholder = {'请输入奖励名称'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    {
                      this.props.id
                      ? <tr>
                        <td>
                          <FormItem
                            label={'奖励代码：'}
                            required
                            labelCol={{span: 3}}
                            wrapperCol={{span: 6, offset: 1}}>
                              <Input name='reward_code'
                                id='reward_code'
                                disabled
                                value={formData.reward_code}
                                placeholder = {'请输入奖励代码'}/>
                          </FormItem>
                        </td>
                      </tr>
                      : <tr style={{display: 'none'}}>
                        <td></td>
                      </tr>
                    }
                    <tr>
                      <td>
                        <FormItem
                          label={'发放周期：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 3, offset: 1}}
                          validateStatus={this._renderValidateStyle('cycle')}
                          help={status.cycle.errors ? status.cycle.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请选择发放周期'}]}>
                            <Select size='large' placeholder='请选择发放周期' style={{width: '100%'}} name='cycle' value={formData.cycle}>
                              <Option value='ONCE'>一次性</Option>
                              <Option value='DAY'>每天</Option>
                              <Option value='week'>每周</Option>
                              <Option value='MONTH'>每月</Option>
                              <Option value='YEAR'>每年</Option>
                            </Select>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'发放次数限制(次)：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 3, offset: 1}}
                          validateStatus={this._renderValidateStyle('limit')}
                          help={status.limit.errors ? status.limit.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请输入发放次数'}, {whitespace: true, message: '请输入发放次数'}, {validator: this._checkDelayDays}]}>
                            <Input name='limit'
                              id='limit'
                              value={formData.limit ? formData.limit + '' : ''}
                              placeholder = {'请输入发放次数'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'自动发放：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 6, offset: 1}}
                          validateStatus={this._renderValidateStyle('auto_gained')}
                          help={status.auto_gained.errors ? status.auto_gained.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请选择自动发放'}]}>
                            <RadioGroup name='auto_gained' value={formData.auto_gained !== null && formData.auto_gained !== undefined ? formData.auto_gained + '' : ''}>
                              <Radio value='true'>是</Radio>
                              <Radio value='false'>否</Radio>
                            </RadioGroup>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'固定奖励：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 19, offset: 1}}
                          validateStatus={this._renderValidateStyle('fixed')}
                          help={status.fixed.errors ? status.fixed.errors.join(',') : null}>
                           <Row>
                            <Col span='24'>
                              <Validation.Validator rules={[{required: true, message: '请选择固定奖励'}]}>
                                <RadioGroup name='fixed' value={formData.fixed !== null && formData.fixed !== undefined ? formData.fixed + '' : ''}>
                                  <Radio value='true'>是</Radio>
                                  <Radio value='false'>否</Radio>
                                </RadioGroup>
                              </Validation.Validator>
                              <div className='warn'>{formData.fixed + '' === 'true' ? tips[0] : tips[1]}</div>
                            </Col>
                          </Row>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'奖励有效期(天)：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 3, offset: 1}}
                          validateStatus={this._renderValidateStyle('validate_days')}
                          help={status.validate_days.errors ? status.validate_days.errors.join(',') : null}>
                          <Validation.Validator rules={[{required: true, message: '请输入奖励有效期'}, {whitespace: true, message: '请输入奖励有效期'}, {validator: this._checksChedule}]}>
                            <Input name='validate_days'
                              id='validate_days'
                              value={formData.validate_days + ''}
                              placeholder = {'请输入奖励有效期'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'奖励用途描述：'}
                          labelCol={{span: 3}}
                          wrapperCol={{span: 6, offset: 1}}
                          validateStatus={this._renderValidateStyle('reward_purpose')}
                          help={status.reward_purpose.errors ? status.reward_purpose.errors.join(',') : null}>
                          <Validation.Validator rules={[{max: 256, message: '奖励用途描述不能超过256字符'}, {whitespace: true, message: '请输入奖励用途描述'}]}>
                            <Input name='reward_purpose'
                              type='textarea'
                              style={{height: 100}}
                              id='reward_purpose'
                              value={formData.reward_purpose}
                              placeholder = {'请输入奖励用途描述'}/>
                          </Validation.Validator>
                        </FormItem>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <FormItem
                          label={'奖励明细：'}
                          required
                          labelCol={{span: 3}}
                          wrapperCol={{span: 20, offset: 1}}>
                            <ul className='title-ul'>
                             <li></li>
                             <li title={'普通用户奖励'}>普通用户奖励</li>
                            {
                              bonus.map((item, key) => {
                                return <li title={item.name} key={key}>
                                      {item.name}
                                    </li>
                              })
                            }
                            </ul>
                            {
                              rewards.map((item, key) => {
                                return <UlForm bonus={bonus} ref={`ref${key}`}
                                          rewark={item} key={key}
                                          bonus_items={formData.bonus}
                                          reward_items={formData.reward_items}
                                        />
                              })
                            }
                        </FormItem>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </Validation>
            </Form>
          </div>
        </div>
        <div className='col-24 text-center margin-bottom-1em'>
          <Button
            type='primary'
            style={{marginRight: '20px'}}
            size='large'
            onClick={this._handleSubmit}>
            {'保存'}
          </Button>
          {
            this.props.id
            ? <Button
              type='primary'
              size='large'
              style={{marginRight: '20px'}}
              onClick={this._handleComp.bind(this, true)}>
              {'修改比对'}
            </Button>
            : ''
          }
          {
            this.props.id
            ? <Button
              type='primary'
              size='large'
              style={{marginRight: '20px'}}
              onClick={this._handleShowLogs}>
              {'查看修改日志'}
            </Button>
            : ''
          }
          <Button
            size='large'
            type='ghost'
            onClick={this._handleBack}>
            {'返回'}
          </Button>
        </div>
      </div>
  }

  _setCompDatas = (datas) => {
    let formData = {
      reward_code: datas.reward_code,
      reward_name: datas.reward_name,
      cycle: datas.cycle,
      limit: datas.limit,
      auto_gained: datas.auto_gained,
      fixed: datas.fixed,
      validate_days: datas.validate_days
    }

    for (let data of datas.reward_items) {
      formData[data.item_code] = data.num
    }

    for (let data of datas.bonus) {
      for (let reward_item of data.reward_items) {
        formData[reward_item.item_code + data.bonus_code] = reward_item.num
      }
    }
    this.state.datas = formData
  }

  _handleComp = (flag) => {
    let formData = {
      reward_code: this.state.formData.reward_code,
      reward_name: this.state.formData.reward_name,
      cycle: this.state.formData.cycle,
      limit: this.state.formData.limit,
      auto_gained: this.state.formData.auto_gained,
      fixed: this.state.formData.fixed,
      validate_days: this.state.formData.validate_days
    }
    let rewards = this.props.datas.rewards.items
    let bonus = this.props.datas.bonus.items
    for (let i = 0; i < rewards.length; i++) {
      keys[rewards[i].item_code] = rewards[i].name + '普通用户奖励'
      let form = this.refs[`ref${i}`].getStatus()
      if (form.isCheck) {
        formData[rewards[i].item_code] = form.name
      }
    }
    for (let j = 0; j < bonus.length; j++) {
      for (let i = 0; i < rewards.length; i++) {
        keys[rewards[i].item_code + bonus[j].item_code] = rewards[i].name + bonus[j].name
        let form = this.refs[`ref${i}`].getStatus()
        if (form.isCheck) {
          if (form[`name${j}`].trim() && form[`name${j}`].trim() !== '0') {
            formData[rewards[i].item_code + bonus[j].item_code] = form[`name${j}`]
          }
        }
      }
    }
    Object.keys(this.state.datas).map(key => {
      if (this.state.datas[key] + '' === formData[key] + '') {
        this.state.datas[key] = formData[key]
      }
    })
    return configLogs.showDiff(this.state.datas, formData, keys, flag)
  }

  _handleShowLogs = () => {
    const config_app_id = '养成管理后台.任务配置.任务管理.奖励列表.修改奖励'
    const config_id = this.state.formData.reward_code
    configLogs.showLogs(utils.CONFIG_LOGS, config_app_id, config_id, keys)
  }
}
