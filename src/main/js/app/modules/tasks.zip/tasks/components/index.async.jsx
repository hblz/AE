import React from 'react'
import '../i18n'
import '../reducers'
import './static/styles/index.scss'

export default class extends React.Component {
  render () {
    return this.props.children
  }
}
