import React, {Component, PropTypes} from 'react'
import AntUploadFile from 'components/upload/antindex'
import { connect } from 'react-redux'
import actionCreators from 'modules/tasks/actions'
import utils from 'utils'
import i18n from 'i18n'
import {message} from 'antd'
const t = i18n.getFixedT(null, 'tasks')

@connect(null, actionCreators, null, {withRef: true})
export default class extends Component {
  static propTypes = {
    multiple: PropTypes.bool,
    dentryIds: PropTypes.array
  }

  static defaultProps = {
    multiple: true,
    dentryIds: []
  }

  // public
  upload() {

    let uploadData = this.refs.uploader.upload()
    let files  = this.refs.uploader.state.file
    uploadData.formData.icon  = files.length > 0 &&  files[0].info ? this.refs.uploader.state.file[0].info.name : 'error'
    const {multiple, dentryIds} = this.props

    if (uploadData.formData.length === 0) { // no new files
      let res = dentryIds.map(id => ({
        dentry_id: id
      }))

      return Promise.resolve(multiple ? res : res[0])
    }

    return new Promise((resolve, reject) => {
      let hideLoading = message.loading(i18n.t('upload.ing'), 0)
      this.props.upload({
        multiple: multiple,
        formData: uploadData.formData,
        success: {
          text: null,
          handler: data => {
            hideLoading()
            resolve(data.uploadRes)
          }
        },
        error: {
          text: '上传失败',
          handler: err => {
            hideLoading()
            reject(err)
          }
        }
      })
    })
  }

  // public
  setFile(uid) {
    this.refs.uploader.setFile(uid)
  }

  setOldFile(uid) {
    this.refs.uploader.setOldFile(uid)
  }

  getFile() {
    return this.refs.uploader.getFile()
  }

  render() {
    const {multiple, dentryIds} = this.props
    let existFiles = dentryIds.map(id => ({
      uid: id,
      name: '',
      status: 'done',
      url: `${id}`,
      thumbUrl: `${id}?size=120`
    }))

    const uploadConfig = {
      remote: {
        formData: {
          scope: 1
        }
      }
    }

    return (
      <AntUploadFile
        className="live-upload"
        ref='uploader'
        file={existFiles}
        multiple={multiple}
        accept="image/png, image/jpeg, image/jpg, image/bmp"
        size={5 * 1024 * 1024}
        uploadWarn={i18n.t('upload.sizeLessThan', {size: 5})}
        pUploadPic={i18n.t('upload.extTip', {ext: 'bmp png jpeg jpg'})}
        formatContent={i18n.t('upload.imgTypeTip')}
        imgType={['.bmp', '.gif', '.png', '.jpeg', '.jpg']}
        config={uploadConfig}
      />
    )
  }
}
