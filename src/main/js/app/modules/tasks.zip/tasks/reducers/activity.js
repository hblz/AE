import actionTypes from '../constants'

export default function (state = {}, action = null) {
  const {type, payload} = action

  switch (type) {
    case actionTypes.GET_ACTIVITYLIST:
      return payload.data || {}
    default:
      return state
  }
}
