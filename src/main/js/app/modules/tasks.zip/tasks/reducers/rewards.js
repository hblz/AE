import { handleActions } from 'redux-actions'
import actionTypes from '../constants'

export default handleActions({
  [actionTypes.GET_REWARDS_LIST]: {
    next (state, action) {
      let lists = action.payload._list.data
      let dics = action.payload.list[0] ? action.payload.list[0].data.items : []
      for (let data of lists.items) {
        for (let item of data.reward_items) {
          for (let dic of dics) {
            if (item.item_code === dic.item_code) {
              item.name = dic.name
              break
            }
          }
        }
      }
      return {
        ...state,
        ...lists
      }
    },
    throw (state, action) {
      return {
        ...state
      }
    }
  }
}, {})
