import { handleActions } from 'redux-actions'
import actionTypes from '../constants'

export default handleActions({
  [actionTypes.GET_TASKSLIST]: {
    next (state, action) {
      let data = action.payload.data
      return {
        ...state,
        ...data
      }
    },
    throw (state, action) {
      return {
        ...state
      }
    }
  }
}, {})
