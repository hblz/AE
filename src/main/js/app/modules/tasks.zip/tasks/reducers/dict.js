import { handleActions } from 'redux-actions'
import actionTypes from '../constants'

export default handleActions({
  [actionTypes.DICT_REWARDS]: {
    next (state, action) {
      let data = action.payload.data
      return {
        ...state,
        rewards: data
      }
    },
    throw (state, action) {
      return {
        ...state
      }
    }
  },
  [actionTypes.DICT_BONUS]: {
    next (state, action) {
      let data = action.payload.data
      return {
        ...state,
        bonus: data
      }
    },
    throw (state, action) {
      return {
        ...state
      }
    }
  },
  [actionTypes.DICT_CYCLE]: {
    next (state, action) {
      let data = action.payload.data
      return {
        ...state,
        cycle: data
      }
    },
    throw (state, action) {
      return {
        ...state
      }
    }
  }
}, {})
