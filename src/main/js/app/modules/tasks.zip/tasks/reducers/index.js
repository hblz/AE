import { appendReducer } from 'store'

import tasks from './tasks'
import rewards from './rewards'
import dicts from './dict'
import taskslist from './list'
import business from './business'
import statusType from './statusType'
import activity from './activity'
import presetTimeTask from './presetTime'

export default appendReducer({
  tasks,
  activity,
  dicts,
  taskslist,
  presetTimeTask,
  business,
  rewards,
  statusType
})
