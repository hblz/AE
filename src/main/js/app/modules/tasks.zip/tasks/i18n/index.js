import { addResources } from 'i18n'
addResources('tasks', require.context('./locales/', true, /\.json$/))
